// import React from 'react';
// import { courseGrade } from '../componentControllers/GradeCalculations';

// const course = {
//     "Course Name": "AI"
// }
// const assignments = [
//     {"Completed": true,
//     "Goal": 90,
//     "Grade": 66,
//     "Name": "A3",
//     "Total Grade": 100,
//     "Type": "Assginment",
//     "Weighting": 20},
//     {"Completed": true,
//     "Goal": 90,
//     "Grade": 90,
//     "Name": "A3",
//     "Total Grade": 100,
//     "Type": "Assginment",
//     "Weighting": 20},
//     {"Completed": true,
//     "Goal": 90,
//     "Grade": 59,
//     "Name": "A3",
//     "Total Grade": 100,
//     "Type": "Assginment",
//     "Weighting": 20},
//     {"Completed": true,
//     "Goal": 90,
//     "Grade": 42,
//     "Name": "A3",
//     "Total Grade": 100,
//     "Type": "Assginment",
//     "Weighting": 20},
//     {"Completed": true,
//     "Goal": 90,
//     "Grade": 80,
//     "Name": "A3",
//     "Total Grade": 100,
//     "Type": "Assginment",
//     "Weighting": 20},
    
// ]

// export default class TempCourseGrade extends React.Component {
//     //This is all temporary code, will update once we make it more dynamic
//   render() {
//     return (
//         <div>
//             <button onClick={() => {courseGrade(assignments, course)}}>Calculate Course Grade</button>
//         </div>
//     );
//   }
// }
