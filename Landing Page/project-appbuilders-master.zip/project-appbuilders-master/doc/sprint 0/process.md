Organizing The Team

First we used the class discussion board on Piazza in order to look for other group members. From there we contacted each other using 
our University of Toronto email accounts in order to form the group. From there we decided to use Discord in order to communicate with 
each other more easily, so we exchanged information to make a Discord group. Then we added our utorIDs, emails, and phone numbers to 
the team.md file on GitHub, so anyone in the group can contact anyone else whenever they need to.

Decision Making

At first, to make decisions, we would suggest something on Discord and discuss it a bit, then meet up in person after a lecture or 
tutorial in order to discuss it more and make a final decision. For deciding what to do for the project we created an ideas text file 
on GitHub and mentioned, through Discord, to add any project ideas to it. Then we took a majority vote to decide which idea would be 
the best to do. We also decided to choose everyone�s responsibilities for sprint zero by splitting up the work into mostly even parts 
and then allowing people to choose which part they wanted and making sure everyone else found that acceptable. In deciding the priority 
of user stories we had one person suggest a priority and then if anyone objected then they explained why and then we would see if 
anyone objected to that priority. Usually everyone agreed with the initially proposed priorities, and only a couple of priorities 
needed to be changed.

Meetings

We started discussing the project over Discord, and just discussed the project at irregular intervals or when deadlines were 
approaching instead of having scheduled meetings. Using Discord we were able to meet in person in tutorial 104 and discuss the project 
more, as well as to solidify ideas we mentioned on Discord. When tutorials ended in less than an hour, we also met outside the room in 
order to further discuss the project in a quieter place. We used the breaks in lecture as well as a bit of time before lecture starts 
in order to finalize things we mention on Discord too. But outside of tutorial and lecture times we meet using Discord a couple of 
times a week. 

Lessons To Take Forward

Moving forward we know we are going to have to find times where everyone can meet, either in person, or online. Right now, not knowing 
when people are available can make it difficult to make decisions online because we don�t know if everyone can respond quickly. This 
causes the big decisions to be delayed and made around lecture and tutorial times. We also know it�s going to be important to 
continue to divide up the work evenly, as well as make sure members are comfortable with their workload. This has been working well 
in the project so far and would be good to continue to not cause too much stress.
