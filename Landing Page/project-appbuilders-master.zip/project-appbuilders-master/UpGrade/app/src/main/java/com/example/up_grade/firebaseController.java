package com.example.up_grade;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class firebaseController {
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    //private static List list_of_courses = new ArrayList();

    public void addUser(String userEmail, String userFirst, String userLast)
    {
        Map<String, Object> user = new HashMap<>();

        user.put("Username", "");
        user.put("Password", "");
        user.put("First Name", userFirst);
        user.put("Last Name", userLast);
        user.put("Last 'Email", userEmail);

        //Temporarily using person email as the doc id
        db.collection("users").document(userEmail)
                .set(user, SetOptions.merge())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("Firebase", "User successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("Firebase", "Error writing User", e);
                    }
                });
    }
    public void addCourse(String userEmail, String courseName, String courseCode, String courseProf, String courseTa, int courseGrade, String completed){
        Boolean status;
        Integer progress;
        if (completed == "Completed"){
            status = true;
            progress = 100;
        }
        else{
            status = false;
            progress = 0;
        }
        Map<String, Object> course = new HashMap<>();

        course.put("Completed", status);
        course.put("Course Code", courseCode);
        course.put("Course Name", courseName);
        course.put("Grade", courseGrade);
        course.put("Professor", courseProf);
        course.put("Teacher Assistant", courseTa);
        course.put("Progress", progress);

        db.collection("users").document(userEmail).collection("Courses").document()
                .set(course, SetOptions.merge())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("Firebase", "Course successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("Firebase", "Error writing Course", e);
                    }
                });
    }

    public void addAssignment(final String userEmail, String assignmentName, int assignmentGrade, int assignmentGoal, int assignmentTotal, int Weighting, String completed, String courseCode){
        Boolean status;
        int grade;
        if (completed == "Completed"){
            status = true;
            grade = assignmentGrade;
        }
        else{
            status = false;
            grade = -1;
        }
        final Map<String, Object> assignments = new HashMap<>();

        assignments.put("Completed", status);
        assignments.put("Name", assignmentName);
        assignments.put("Goal", assignmentGoal);
        assignments.put("Grade", grade);
        assignments.put("Total Grade", assignmentTotal);
        assignments.put("Type", "");
        assignments.put("Weighting", Weighting);

        getCourseId(userEmail, courseCode, new courseCallBack() {
            @Override
            public void oncourseCallBack(Map data) {
                db.collection("users").document(userEmail).collection("Courses").document((String) data.get("Course ID")).collection("Assignments").document()
                        .set(assignments, SetOptions.merge())
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d("Firebase", "Assignment successfully written!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d("Firebase", "Error writing Assignment", e);
                            }
                        });
            }
        });


    }

    // return user info as a dictionary (contained in a document) given document id
    // returns null if document not found, returns -1 on failure
    public Map getUserInfo(String userDocId) {
        final DocumentReference userRef = db.collection("users").document(userDocId);
        Map<String, Object> userInfo = new HashMap<>();

        userRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("Firebase", "DocumentSnapshot data: " + document.getData());

                        Map<String, Object> userInfo = new HashMap<>();

                        try {
                            userInfo.put("Email", document.get("Email"));
                            userInfo.put("First Name", document.get("First Name"));
                            userInfo.put("Last Name", document.get("Last Name"));
                            userInfo.put("Username", document.get("Username"));
                            userInfo.put("Password", document.get("Password"));
                        }catch (Exception e) {
                            Log.e("Firebase","Error getting document");
                        }
                    } else {
                        Log.d("Firebase", "No such document");
                    }
                } else {
                    Log.d("Firebase", "get failed with ", task.getException());
                }
            }
        });
        return userInfo;
    }

    public void getUserCourses(String userDocId, final callBack myCallback) {
        final CollectionReference userCourseRef = db.collection("users").document(userDocId).collection("Courses");
        final List list_of_courses = new ArrayList();
        userCourseRef.orderBy("Course Code").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {

                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Map course = new HashMap<>();
                        course.put("Completed", document.get("Completed"));
                        course.put("Course Code", document.get("Course Code"));
                        course.put("Course Name", document.get("Course Name"));
                        course.put("Grade", document.get("Grade"));
                        course.put("Progress", document.get("Progress"));
                        course.put("Professor", document.get("Professor"));
                        course.put("Teacher Assistant", document.get("Teacher Assistant"));
                        list_of_courses.add(course);
                        //Log.w("Firebase",list_of_courses.toString());
                    }
                    myCallback.onCallBack(list_of_courses);
                } else {
                    Log.d("Firebase", "No such document");
                }
            }
        });
    }

    public void getUserAssignments(final String userDocId, String courseCode, final callBack assignmentCallback){
        CollectionReference userCourseRef = db.collection("users").document(userDocId).collection("Courses");
        final List list_of_assignments = new ArrayList();

        userCourseRef.whereEqualTo("Course Code", courseCode).limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if(!document.exists()){
                            Log.d("Firebase","No matching document");
                            return;
                        }
                        String courseId = document.getId();
                        CollectionReference assignmentRef = db.collection("users").document(userDocId).collection("Courses")
                                .document(courseId).collection("Assignments");
                        assignmentRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        Map assignment = new HashMap<>();
                                        assignment.put("Completed", document.get("Completed"));
                                        assignment.put("Goal", document.get("Goal"));
                                        assignment.put("Name", document.get("Name"));
                                        assignment.put("Grade", document.get("Grade"));
                                        assignment.put("Total Grade", document.get("Total Grade"));
                                        assignment.put("Type", document.get("Type"));
                                        assignment.put("Weighting", document.get("Weighting"));
                                        list_of_assignments.add(assignment);
                                    }
                                    assignmentCallback.onCallBack(list_of_assignments);
                                } else {
                                    Log.d("Firebase", "No such document");
                                }
                            }
                        });
                    }
                } else {
                    Log.d("Firebase", "Error getting documents: ", task.getException());
                }
            }
        });
    }

    public void getCourseInfo(String userDocId, String courseCode, final courseCallBack courseInfoCallback){
        final CollectionReference userCourseRef = db.collection("users").document(userDocId).collection("Courses");
        final Map course = new HashMap<>();

        userCourseRef.whereEqualTo("Course Code", courseCode).limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if(!document.exists()){
                            Log.d("Firebase","No matching document");
                            return;
                        }
                        course.put("Completed", document.get("Completed"));
                        course.put("Course Code", document.get("Course Code"));
                        course.put("Course Name", document.get("Course Name"));
                        course.put("Grade", document.get("Grade"));
                        course.put("Progress", document.get("Progress"));
                        course.put("Professor", document.get("Professor"));
                        course.put("Teacher Assistant", document.get("Teacher Assistant"));
                    }
                    courseInfoCallback.oncourseCallBack(course);
                } else {
                    Log.d("Firebase", "No such document");
                }
            }
        });
    }

    public void getAssignmentInfo(final String userDocId, final String assignmentName, String courseCode, final courseCallBack courseInfoCallback){
        final Map assignment = new HashMap<>();
        getCourseId(userDocId, courseCode, new courseCallBack() {
            @Override
            public void oncourseCallBack(Map data) {
                CollectionReference userAssignmentRef = db.collection("users").document(userDocId)
                        .collection("Courses").document((String) data.get("Course ID")).collection("Assignments");
                userAssignmentRef.whereEqualTo("Name", assignmentName).limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if(!document.exists()){
                                    Log.d("Firebase","No matching document");
                                    return;
                                }
                                assignment.put("Completed", document.get("Completed"));
                                assignment.put("Goal", document.get("Goal"));
                                assignment.put("Name", document.get("Name"));
                                assignment.put("Grade", document.get("Grade"));
                                assignment.put("Total Grade", document.get("Total Grade"));
                                assignment.put("Deadline", document.get("Deadline"));
                                assignment.put("Weighting", document.get("Weighting"));
                                assignment.put("Calculated Goal", document.get("Calculated Goal"));
                            }
                            Log.w("Firebase", assignment.toString());
                            courseInfoCallback.oncourseCallBack(assignment);
                        } else {
                            Log.d("Firebase", "No such document");
                        }
                    }
                });
            }
        });
    }

    public void getCourseId(String userDocId, final String courseCode, final courseCallBack courseIDCallback){
        final CollectionReference userCourseRef = db.collection("users").document(userDocId).collection("Courses");
        final Map courseIdContainer = new HashMap<>();

        userCourseRef.whereEqualTo("Course Code", courseCode).limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if(!document.exists()){
                            Log.d("Firebase","No matching document");
                            return;
                        }
                        courseIdContainer.put("Course ID", document.getId());
                    }
                    courseIDCallback.oncourseCallBack(courseIdContainer);
                } else {
                    Log.d("Firebase", "No such document");
                }
            }
        });
    }
    public int getCourseGrade(final String userDocId, String courseCode){
        CollectionReference userCourseRef = db.collection("users").document(userDocId).collection("Courses");
        final int[] courseGrade = {100};
        userCourseRef.whereEqualTo("Course Code", courseCode).limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if(!document.exists()){
                            Log.d("Firebase","No matching document");
                            return;
                        }
                        final String courseId = document.getId();
                        CollectionReference assignmentRef = db.collection("users").document(userDocId).collection("Courses")
                                .document(courseId).collection("Assignments");
                        assignmentRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {

                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        if((boolean) document.get("Completed")) {
                                            double grade = 100 - (((int) document.get("Grade") / (int) document.get("Total Grade")) * 100);
                                            double weight = (double) document.get("Weighting")/100;
                                            courseGrade[0] -= Math.round(grade * weight);
                                        }
                                    }
                                    db.collection("users").document(userDocId).collection("Courses")
                                            .document(courseId).update("Grade", courseGrade[0]);
                                } else {
                                    Log.d("Firebase", "No such document");
                                }
                            }
                        });
                    }
                } else {
                    Log.d("Firebase", "Error getting documents: ", task.getException());
                }
            }
        });
        return courseGrade[0];
    }

    public double getGPA(final String userDocId, String courseCode){
        final int grade = getCourseGrade(userDocId, courseCode);
        double gpa;
        if(grade >= 85 && grade <= 100){
            gpa = 4.0;
        } else if(grade >= 80){
            gpa = 3.7;
        } else if(grade >= 77){
            gpa = 3.3;
        } else if(grade >= 73){
            gpa = 3.0;
        } else if(grade >= 70){
            gpa = 2.7;
        } else if(grade >= 67){
            gpa = 2.3;
        } else if(grade >= 63){
            gpa = 2.0;
        } else if(grade >= 60){
            gpa = 1.7;
        } else if(grade >= 57){
            gpa = 1.3;
        } else if(grade >= 53){
            gpa = 1.0;
        } else if(grade >= 50){
            gpa = 0.7;
        } else {
            gpa = 0.0;
        }
        return gpa;
    }

}
