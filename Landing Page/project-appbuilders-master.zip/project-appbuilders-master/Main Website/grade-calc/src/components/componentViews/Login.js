//Do not remove this import
import React, { Component } from 'react';
//Any imports would go here
import '../css/login.css';
import { auth } from '../databaseController/firebase.js';
import {login} from '../componentControllers/LoginController.js';

class Login extends Component {
    //ANY BACK END CODE/FUNCTIONS WOULD GO HERE
    constructor(props) {
      super();
      this.state = {
        password: '',
        username: '',
        user: null
      }
      this.props = props;
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this); 
      login.bind(this);
    }
      
    handleChange(e) {
      this.setState({
        [e.target.name]: e.target.value
      });
    }

    async handleSubmit(e) {
      e.preventDefault();
      await login(this)
      // window.location.href='/Home';
      // this.props.history.push({pathname: '/home',state: {uid: user.uid}})
      this.props.history.push({pathname: '/home'});
    }


    componentDidMount() {
      // var user = auth.currentUser;
      // if(user){
      //   console.log("sign in as", user.uid);
      //   //this.setState({ user: user.uid });
      // }else{
      //   console.log("not signed in");
      //   //this.setState({ user: null });
      // }

      auth.onAuthStateChanged((user)=>{
        if(user){
            console.log("sign in as", user.uid);
            this.setState({ user: user.uid });
          }else{
            console.log("not signed in");
            this.setState({ user: null });
          }

    });}

      
  render() {
    return (
      // FRONT END CODE GOES HERE
      <div className='Login'>
      <header className = "loginHeader">
        <h1>Up-Grade</h1>
      </header>
        <div className='container'>
        <section className= "login-box">
          <form onSubmit = {this.handleSubmit.bind(this)}>
            {/* <input className = "loginInput" type="text" name="username" placeholder="username" onChange={this.handleChange} value={this.state.username} />
            <input className = "loginInput" type="text" name="password" placeholder="password" onChange={this.handleChange} value={this.state.password} /> */}
            <button className="loginButton">Log In</button>
          </form>
        </section>
        </div>
        {this.state.user ?
          <div>
            <p>Logged In</p>
          </div>
          :
          <div className='wrapper'>
            <p>Not Logged In</p>
          </div>}
      </div>
    );
  }

}
export default Login;
