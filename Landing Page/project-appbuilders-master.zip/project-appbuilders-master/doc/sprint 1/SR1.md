#  Sprint 1 Retrospective Meeting

## Participants
- Haodong Mai
- Tya Jubandhu
- Ze Chen
- Brendan Maclean
- Yu Heng Su
- Evan Gilchrist

## Practices to continue
- Regular Meetings:
  - This helped us a lot during this sprint since we are constantly updating each other what is being worked on
- Helping other team members when they are struggling:
  - This has helped team members who were struggling continue their work and learn at the same time
- Asking questions:
  - It is always okay to seek clarity about the user stories
  
## New Practices
- Starting the work earlier
  - Focus on finishing the user stories before the deadline to allow room for bug fixing
- Staying Work-Focused
  - Be more focus when working on the user storeis

## New Potential Features for Sprint 2
- Mobile development
- Journal/Log for each courses
- Degree planner
- Features to include the teacher as the user
  - Allow teachers to leave feedback for the students
  
## Best Experience
- Helping others when they were struggling
- Learning new technology
- Designing an application
- Developing a program from fresh

## Worst Experience
- Figuring out bugs in the new technology
