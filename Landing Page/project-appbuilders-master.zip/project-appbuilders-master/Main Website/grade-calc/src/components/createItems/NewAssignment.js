import React from 'react';
import Calendar from 'react-calendar';
import Popup from "reactjs-popup";
import {addAssignment} from '../databaseController/firebase.js'
import {examGrade} from '../componentControllers/GradeCalculations'


export default class NewAssignment extends React.Component {
    constructor(code) {
        super();
        this.state = {
          name:'',
          type: 'Assignment',
          gradeGoal:'',
          gradeTotal:'',
          weight:'',
          deadline:''
        }
        this.code = code;
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this); 
      }

        handleChange(e) {
          this.setState({
            [e.target.name]: e.target.value
          });
        }

        changeDate = deadline=> {
          //console.log(deadline.substr(4,15))
          var uk = new Date(deadline)
          var u = uk.toLocaleDateString()
          return this.setState({ deadline: u });
        }
        
        async handleSubmit(e) {
            e.preventDefault();
            const code = this.props.code;
            if(this.state.type === "Exam"){
              await examGrade(this.state.weight, code)
              .then (calculatedGoal => {
                addAssignment(code, this.state.type, "Exam", -1, parseInt(this.state.gradeGoal), 100, parseInt(this.state.weight), false, calculatedGoal,this.state.deadline); 
              })
            }
            else
            {
              addAssignment(code, this.state.type, this.state.name, -1, parseInt(this.state.gradeGoal), parseInt(this.state.gradeTotal), parseInt(this.state.weight), false, -1,this.state.deadline);
            }
            this.setState({
                name:'',
                Type: 'Assignment',
                gradeGoal:'',
                gradeTotal:'',
                weight:'',
                deadline:'',
            });
          }
  render() {
    return (
        <div className="modalInfo">
            <h1 id="pastAssignments">Adding Future Assignment</h1>
            <form className="assignmentForm" onSubmit = {this.handleSubmit.bind(this)}>
              <label>Type: </label><select className="documentType" name ="type" onChange={this.handleChange} value={this.state.type}>
                  <option value="Assignment">Assignment</option>
                  <option value="Test">Test</option>
                  <option value="Exam">Exam</option>
                  <option value="Other">Other</option>
              </select>
              <br></br>
                  {this.state.type === "Exam"?
                  <div className="documentInfo">
                    <label>Exam weight: </label>
                    <input type="text" className="inputForm" name ="weight" onChange={this.handleChange} value={this.state.weight}/>
                    <br></br>
                    <label>Goal for the grade: </label>
                    <input type="text" className="inputForm" name ="gradeGoal" onChange={this.handleChange} value={this.state.gradeGoal}/>
                    <br></br>
                    <label>Deadline</label>
                    <Popup trigger = {<input type="text" id="Deadline" name ="deadline" onChange={this.handleChange} value={this.state.deadline}/>} modaltrigger position = "right center">
                    <div className="modal">
                    <div className="calendarContent">
                    <Calendar locale="en" onChange={this.changeDate} />
                    </div>  
                    </div>
                    </Popup>
                  </div>
                  :
                  <div className="documentInfo">
                    <label>Assignment name: </label>
                    <input type="text" className="inputForm" name="name" onChange={this.handleChange} value={this.state.name}/>
                    <br></br>
                    <label>Assignment weight: </label>
                    <input type="text" className="inputForm" name ="weight" onChange={this.handleChange} value={this.state.weight}/>
                    <br></br>
                    <label>Goal for the grade: </label>
                    <input type="text" className="inputForm" name ="gradeGoal" onChange={this.handleChange} value={this.state.gradeGoal}/>
                    <br></br>
                    <label>Grade total: </label>
                    <input type="text" className="inputForm" name ="gradeTotal" onChange={this.handleChange} value={this.state.gradeTotal}/>
                    <br></br>
                    <label>Deadline</label>
                    <Popup trigger = {<input type="text" id="Deadline" name ="deadline" onChange={this.handleChange} value={this.state.deadline}/>} modaltrigger position = "right center">
                    <div className="modal">
                    <div className="calendarContent">
                    <Calendar locale="en" onChange={this.changeDate} />
                    </div>  
                    </div>
                    </Popup>
                  </div>
                  }

                  <button className="saveButton">Save</button>
            </form>
        </div>
        
    
    );
  }
}
