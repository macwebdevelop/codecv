# Release Planning Meeting
## Goals:
- Our goal is to allow the user to be able to track their progress throughout the school year and to provide feedbacks to the user to help them improve their GPA
- Our goal is also to have the application running on the web browser

## Scope:
- The scope of our project is to create a simple yet useful program that allows the user to easily track their marks in school
- This application will be available on the web browser
- It will include many features such as:
  - The ability to login and logout
  - GPA Calculator
  - Assignment tracker
  - Course tracker
  - Assignment reminders (Calendar)
  - Visuals for the data
  - And many more
- Part of the scope will also be to learn how to program with firebase, react and android applications

## Participants
- Haodong Mai
- Yu Heng Su
- Tya Jubandhu
- Evan Gilchrist
- Brendan Maclean
- Ze Chen




