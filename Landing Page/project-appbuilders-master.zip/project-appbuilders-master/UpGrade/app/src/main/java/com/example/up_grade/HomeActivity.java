package com.example.up_grade;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;
import java.util.Map;


public class HomeActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;

    private Button signOutButton, assignmentButton, courseButton;

    private GoogleSignInClient mGoogleSignInClient;
    //private GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
    private firebaseController controller = new firebaseController();
    private  String TAG = "HomeActivity";
    //private List<Map> userCourses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mAuth = FirebaseAuth.getInstance();

        signOutButton = findViewById(R.id.sign_out_button);
        assignmentButton = findViewById(R.id.createAssignments);
        courseButton = findViewById(R.id.createCourses);


        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        String personEmail = account.getEmail();
        Log.w(TAG,"email is " + personEmail);
        //List<Map> userCourses =
        controller.getUserCourses(personEmail, new callBack() {
            @Override
            public void onCallBack(List<Map> data) {
                Log.w(TAG,data.toString());
                for(Map course:data){
                    Log.w(TAG,"Course code is " + course.get("Course Code"));
                }
            }
        });
//        Log.w(TAG,userCourses.toString());
//        Log.w(TAG,controller.getList_of_courses());
//        for(Map course:userCourses){
//            Log.w(TAG,"Course code is" + course.get("Course Code"));
//        }

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                courseNaviUI();
            }
        });

        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();
                updateUI();
                Toast.makeText(HomeActivity.this,"You are Logged Out",Toast.LENGTH_SHORT).show();
            }
        });

        assignmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addAssignmentUI();
            }
        });

        courseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addCourseUI();
            }
        });
    }

    private void addAssignmentUI(){
        Intent intent = new Intent(this,AssignmentCreation.class);
        startActivity(intent);
    }

    private void addCourseUI(){
        Intent intent = new Intent(this,CourseCreation.class);
        startActivity(intent);
    }

    private void courseNaviUI(){
        Intent intent = new Intent(this,CourseNavigation.class);
        startActivity(intent);
    }

    private void updateUI(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

//    private void updateCourseList(List<Map> userCourses){
//        this.userCourses = userCourses;
//    }
}
