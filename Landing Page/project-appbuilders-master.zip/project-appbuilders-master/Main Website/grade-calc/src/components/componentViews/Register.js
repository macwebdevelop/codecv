//Do not remove this import
import React, { Component } from 'react';
//Any imports would go here
import '../css/register.css';
import {registerUser} from '../databaseController/firebase.js'

class Register extends Component {
    //ANY BACK END CODE/FUNCTIONS WOULD GO HERE
    constructor() {
      super();
      this.state = {
        password: '',
        username: '',
        email: ''
      }
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }

      handleChange(e) {
        this.setState({
          [e.target.name]: e.target.value
        });
      }
    
      handleSubmit(e) {
        e.preventDefault(); 
        registerUser(this.state.username, this.state.password, '', '', this.state.email);
        
        this.setState({
          username: '',
          password: '',
          email: ''
        });
      }
      
  render() {


    return (
        // FRONT END CODE GOES HERE
        <div className='register'>
        <header className = "registerHeader">
          <h1>GradeCalc</h1>
        </header>
        <div className='container'>
          <section className= "register-box">
                <form onSubmit = {this.handleSubmit.bind(this)}>
                <input className = "registerInput" type="text" name="username" placeholder="username" onChange={this.handleChange} value={this.state.username} />
                <input className = "registerInput" type="text" name="password" placeholder="password" onChange={this.handleChange} value={this.state.password} />
                <input className = "registerInput" type="text" name="email" placeholder="email" onChange={this.handleChange} value={this.state.email} />
                <button className = "registerButton">Register</button>
              </form>
          </section>
        </div>
      </div>
      // FOR TESTING PURPOSES ONLY, COMMENT BELOW AND UNCOMMENT ABOVE BEFORE PUBLISHING
      /*
      <div>
          <button onClick={() => {getUpcomingAssignments('appbuilders.gradecalc@gmail.com')}}>Test</button>
      </div>*/
      
    );
  }
}
export default Register;