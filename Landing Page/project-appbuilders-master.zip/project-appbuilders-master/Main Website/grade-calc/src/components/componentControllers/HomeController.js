import { Component } from 'react';
import {deleteCourse, getUpcomingAssignments, deadlineHelper} from '../databaseController/firebase.js';
import {gpaCalculator} from '../componentControllers/GradeCalculations';
export default class HomeController extends Component{
	constructor(props)
	{
		super(props);
	}
	gpaView(courses){
		//Displays and calculate the GPA
		let view = document.getElementById("gpaInfo");
		let grade = gpaCalculator(courses);
		view.innerHTML = "Current GPA: " + grade;
	}
	async deadlineView(userEmail){
		await getUpcomingAssignments(userEmail)
		.then (result => {
				if (result != null){
				console.log(result);
				let container = document.querySelector('.deadlinesContainer');
				for (var i = 0; i < result.length; i ++){
					var deadline = document.createElement("li");
					var courseCode = document.createElement("a");
					courseCode.innerHTML = result[i][0] + ": ";
					courseCode.className = "deadlineCode";

					deadline.innerHTML = result[i][1]["Name"] + ": " + result[i][1]["Deadline"].toDate().toLocaleDateString();
					deadline.className = "deadlineInfo";

					deadline.prepend(courseCode);
					container.appendChild(deadline);
				}
			}
		})
	}
	homeView (courses) {

		if(courses != null){
			//Loop through all the courses and displays their main informations (Progress, grade, status)
			let grid = document.querySelector('#content');
			let len = courses.length;
			var i;
			for (i=0; i<courses.length; i++){
				let code = courses[i]["Course Code"];;
				let progress = courses[i]["Progress"];

				var course = document.createElement("div");
				var courseCode = document.createElement("p");
				var courseName = document.createElement("p");
				var courseGrade = document.createElement("p");
				var courseStatus = document.createElement("p");
				var courseLabel = document.createElement("label");
				var courseProgress = document.createElement("progress");
				var deleteButton = document.createElement("Button");

				if (i === len - 1 && len % 2 === 1) {
					course.className = "proj-span2-title";
				} else {
					course.className = "proj-title"
				}

				courseCode.innerHTML = courses[i]["Course Code"];
				courseCode.className = "courseInfo"

				//Set the onclick function to redirect to the specific course pages
				course.onclick = function(){
					console.log("Directing to", code);
					this.props.history.push({pathname: '/course',state: {code: code}})
					// this.props.history.push({pathname: '/course'});
					
					return false;
				}.bind(this);

				deleteButton.textContent = "Delete";
				deleteButton.className = "deleteButton";
				deleteButton.onclick = function(e){
					e.stopPropagation();
					deleteCourse(code)
					return false;
				}

				courseName.innerHTML = courses[i]["Course Name"];
				courseName.className = "courseName";
				
				course.className = "course-box";

				courseGrade.className = "courseInfo";
				
				courseStatus.className = "courseInfo";
	
				courseLabel.className = "courseInfo";

				courseLabel.innerHTML = "Progress: " + progress + "%";

				courseProgress.className = "courseProgress";
				courseProgress.setAttribute("max","100");

				//If course is completed, then display a final grade and set the status to be completed. Otherwise, display the current grade and attending as the status
				if(courses[i].Completed)
				{
					courseGrade.innerHTML = "Final Grade: " + courses[i]["Grade"] + "%";

					courseStatus.innerHTML = "Status: Completed";

					courseProgress.setAttribute("value", "100");


				}
				else
				{
					courseGrade.innerHTML = "Current Grade: " + courses[i]["Grade"] + "%";
	
					courseStatus.innerHTML = "Status: Attending";
					
					courseProgress.setAttribute("value", progress);
				}

				courseName.appendChild(deleteButton);

				course.appendChild(courseName);
				course.appendChild(courseCode);
				course.appendChild(courseStatus);
				course.appendChild(courseGrade);
				course.appendChild(courseLabel);
				course.appendChild(courseProgress);
				grid.appendChild(course);
			}
		}
		else
		{
			//No courses
			let grid = document.querySelector('#content');
			var course = document.createElement("div");
			var courseError = document.createElement("p");
			
			courseError.className = "errorInfo";
			courseError.innerHTML = "No courses available"

			course.appendChild(courseError);
			grid.appendChild(course);
		}
	}
}
