AppBuilders - GradeCalc Tool Summary

Project Goals

The goal of this project is to build a tool that can provide some utility and perspective to current students about how to
  achieve their academic goals.  Whether it is the likelihood of passing a course, or the drive to keep a high CGPA, this tool 
  is meant to aid in the planning and understanding of students as to where their marks currently sit and their potential based 
  on future assignments, tests and exams.

Key Users

Jim - A first-year student who is struggling in his courses and is trying to attain a minimum GPA of 2.0 to get into his intended 
Political Science Major program.   At the midpoint of the semester he begins to wonder if he can achieve the necessary grades, and 
needs to know what mark he would need on the remaining assignments to finish with a sufficient mark.  He wants to know exactly what 
he needs to achieve on each assignment so he can approach his professor and put a plan together.

Brianna - A third-year honours student, she constantly achieves a minimum of 3.7 GPA in each course of her math major.  Her english 
major classes are not as easily handled, and she desires to maintain a CGPA over 3.3 for a yearly grant she receives towards her 
course fees.  Being a full time student, Brianna wants to have a method to stay on top of her marks and ensure she remains on track 
for her academic goals.

Jeff - A new professor who wants to give his students the most clear understanding of not only his marking schemes and priorities, but 
help them achieve their individual desired marks.  A number of students have expressed their appreciation at receiving rubrics, but 
they also say its difficult to keep track of their many small assignment marks to understand where they stand in the course.  Jeff 
wants to show them exactly how to calculate their current marks without having to repeat the methods to them repeatedly.

Key Scenarios

 Jim is at a 65 in his Intro To Political Science course, and has approximately 30% of his mark left to determine his final grade.  
 This consists of a short assignment worth 5%, and the final exam worth 25%.  He has already submitted the short assignment, and is 
 not confident in how high his mark will be.  He wants to know exactly what mark he might need on the exam, if he fails the assignment, 
 to achieve a minimum of 70 as a final mark.

Brianna has received her second essay back in a Poetry course, and she is beginning to worry this course may drag down her GPA as it 
is a full year course.  The date is approaching to drop the course before it affects her CGPA, and she decides that if her third 
assignment does not raise her mark to at least a 75, then she will remove the course and take it another year.  She needs to be able 
to keep track of her previous marks in the course to ensure that she can calculate her mark when the assignment is returned.  This will 
determine if she leaves the course on that date, which happens to be immediately before the aforementioned drop-date.

Jeff has reworked his course’s mark-breakdown for the upcoming semester.  He wants to show the first-year students how to predict what 
kinds of final grades they might get if they do better or worse on certain assignments, and maintain or lose their participation grades.

Key Principles

Student Ease-of-Access over Excessive Features - instead of implementing any specific features for different majors or problems, i.e. 
difficulty in writing or struggles with complex equations, emphasis will be on ensuring that students from all disciplines can use this
tool with equal ease.

Student Personalization over School-Specific Implementation - Want to make this a more generically usable tool, i.e. able to swap 
U of T GPA scale for other schools, allowing widespread usage.
