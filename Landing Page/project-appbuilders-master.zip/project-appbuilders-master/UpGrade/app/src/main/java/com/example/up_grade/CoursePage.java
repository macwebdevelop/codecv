package com.example.up_grade;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CoursePage extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private Button signOutButton, assignmentButton, courseButton;
    private TextView courseName, courseCode, professor, teachingAssistant, grade, progress;
    private ProgressBar progressBar;
    private Switch completedSwitch;
    private firebaseController controller = new firebaseController();
    private  String TAG = "CoursePageActivity";
    private String course_code;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_page);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        mAuth = FirebaseAuth.getInstance();

        signOutButton = findViewById(R.id.sign_out_button);
        assignmentButton = findViewById(R.id.createAssignments);
        courseButton = findViewById(R.id.createCourses);
        courseName = findViewById(R.id.courseName);
        courseCode = findViewById(R.id.courseCode);
        professor = findViewById(R.id.professor);
        teachingAssistant = findViewById(R.id.teaching_assistant);
        grade = findViewById(R.id.grade);
        progress = findViewById(R.id.progress);
        progressBar = findViewById(R.id.progressBar);
        completedSwitch = findViewById(R.id.completed);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        String personEmail = account.getEmail();

        Intent intent = getIntent();
        course_code = intent.getStringExtra("courseCode");
        Log.w(TAG, course_code);

        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        final Context assignmentTabGenerate = this;

        controller.getCourseInfo(personEmail, course_code, new courseCallBack() {
            //@RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void oncourseCallBack(Map data) {
                Log.w(TAG, data.toString());
                courseName.setText(data.get("Course Name").toString());
                courseCode.setText(data.get("Course Code").toString());
                String profText = "Professor: " + data.get("Professor").toString();
                professor.setText(profText);
                String TAText = "Teacher Assistant: " + data.get("Teacher Assistant").toString();
                teachingAssistant.setText(TAText);
                String gradeText = "Grade: " + data.get("Grade").toString();
                grade.setText(gradeText);
                String progressText = "Progress: " + data.get("Progress").toString() + "%";
                progress.setText(progressText);
                boolean status = (boolean) data.get("Completed");
                if(status){
                    completedSwitch.setChecked(true);
                }else{completedSwitch.setChecked(false);}
                progressBar.setProgress(Integer.parseInt(data.get("Progress").toString()));
            }
        });

        controller.getUserAssignments(personEmail, course_code, new callBack() {
            @Override
            public void onCallBack(List<Map> data) {
                ArrayList<String> assignment_name = new ArrayList<>();
                for(Map assignment:data){
                    assignment_name.add((String)assignment.get("Name"));
                }
                Log.w(TAG, assignment_name.toString());
                mAdapter = new assignmentTabAdapter(assignment_name, course_code,assignmentTabGenerate);
                recyclerView.setAdapter(mAdapter);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_coursepage, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.sign_out_button:
                mAuth.signOut();
                updateUI();
                Toast.makeText(this,"You are Logged Out",Toast.LENGTH_SHORT).show();
                return true;
            case R.id.newAssignment:
                Intent intent = new Intent(this,AssignmentCreation.class);
                intent.putExtra("courseCode", course_code);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateUI(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
