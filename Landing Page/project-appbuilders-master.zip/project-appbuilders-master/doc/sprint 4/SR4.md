#  Sprint 4 Retrospective Meeting

## Participants
- Haodong Mai
- Tya Jubandhu
- Ze Chen
- Brendan Maclean
- Yu Heng Su
- Evan Gilchrist

## Some practices that were used
- Regular Meetings:
  - Bring up any problems or suggestions during standup to increase the quality of the application
- Asking questions:
  - It is always okay to seek clarity about the user stories
  - Always ask for help with problems and bug if needed
- Starting the work earlier
  - Focus on finishing the user stories before the deadline to allow room for bug fixing
- Constantly testing the corner cases for the code
  - To ensure no bug breaking codes
- Code organization
  - Clean up code that is not needed
  - Delete any unnecessary comments/codes

## Best Experience
- Learning how to create the user interface on mobile
- Connecting all the features on the website
- Connecting the front end and back end on the mobile application

## Worst Experience
- Figuring out synchronous and asynchronous functions
- Trying to fix bugs for the mobile application
