# How to run the application

# Web Application
## To run locally
- Install Node.js
- Navigate to grade-calc folder (/Main Website/grade-calc)
- Run npm install
- Potentially have to run:
  - Run npm install react-router-dom
  - Run npm install reactjs-popup
  - Run npm install react-calendar
  - Run npm install react-chartjs-2
- Run npm start after all the installs
- After running 'npm start', it should open a localhost site on your browser, if it didn't just go to 'http://localhost:3000/'
## To visit deployed website
- https://project-app-builders-utm.web.app/

# Mobile Application
- Install Android Studio
- Open the app folder in the UpGrade folder (/UpGrade/app)
- Wait for the gradle sync/build
## To use a phone
- Make sure debug option is on
- Plug the phone in
- Click run/debug and wait for the application to build
