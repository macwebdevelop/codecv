package com.example.up_grade;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;

public class AssignmentCreation extends AppCompatActivity  {
    private TextView assignmentName, assignmentGoal, assignmentGrade, assignmentWeight, assignmentTotalGrade;
    private Button submitButton;
    private FirebaseAuth mAuth;
    private String statusInput;
    private Switch completedSwitch;
    private firebaseController controller = new firebaseController();
    private String course_code;
    private String TAG = "AssignmentCreation";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment_creation);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        mAuth = FirebaseAuth.getInstance();

        assignmentName = findViewById(R.id.assignmentNameText);
        assignmentGoal = findViewById(R.id.assignmentGoalText);
        assignmentGrade = findViewById(R.id.assignmentGradeText);
        assignmentTotalGrade = findViewById(R.id.assignmentTotalGradeText);
        assignmentWeight = findViewById(R.id.assignmentWeightText);
        submitButton = findViewById(R.id.assignmentSubmit);

//        spinner = findViewById(R.id.statusSpinner);
//        spinner.setOnItemSelectedListener(this);
//
//// Create an ArrayAdapter using the string array and a default spinner layout
//        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
//                R.array.statusArray, android.R.layout.simple_spinner_item);
//// Specify the layout to use when the list of choices appears
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//// Apply the adapter to the spinner
//        spinner.setAdapter(adapter);

        Intent intent = getIntent();
        course_code = intent.getStringExtra("courseCode");
        Log.w(TAG, course_code);

        completedSwitch = findViewById(R.id.completed);
        completedSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    statusInput = "Completed";
                } else {
                    // The toggle is disabled
                    statusInput = "NotCompleted";
                }
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submit();
            }
        });
    }

    private void submit(){
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        //Need to change this to writing to database
        String personEmail = account.getEmail();

        String nameInput = assignmentName.getText().toString();
        int goalInput = 100;
        int gradeInput = 100;
        int totalGradeInput = 100;
        int weightInput = 100;
        try{
            goalInput = Integer.parseInt(assignmentGoal.getText().toString());
            gradeInput = Integer.parseInt(assignmentGrade.getText().toString());
            totalGradeInput = Integer.parseInt(assignmentTotalGrade.getText().toString());
            weightInput = Integer.parseInt(assignmentWeight.getText().toString());
        } catch(NumberFormatException nfe) {
            System.out.println("Could not parse " + nfe);
        }
        controller.addAssignment(personEmail, nameInput, gradeInput, goalInput, totalGradeInput, weightInput, statusInput, course_code);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_assignmentcreation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.sign_out_button:
                mAuth.signOut();
                updateUI();
                Toast.makeText(this,"You are Logged Out",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateUI(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
