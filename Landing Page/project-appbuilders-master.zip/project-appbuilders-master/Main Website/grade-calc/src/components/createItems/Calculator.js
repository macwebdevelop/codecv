import React, { Component } from "react";
import '../css/calculator.css';
import ResultComponent from '../componentViews/ResultComponent';
import KeyPadController from "../componentControllers/KeyPadController";

class Calculator extends Component {
  constructor() {
    super();
    this.state = {
      result: ""
    }
  }

  onClick = button => {
    if (button === "=") {
      this.calculate()
    }
    else if (button === "C") {
      this.reset()
    }
    else if (button === "CE") {
      this.backspace()
    }
    else {
      this.setState({
        result: this.state.result + button
      })
    }
  };

  calculate = () => {
    var checkResult = ''
    if (this.state.result.includes('--')){
      checkResult = this.state.result.replace('--','+')
    }
    else {
      checkResult = this.state.result
    }
    
    try {
      this.setState({
        result: (eval(checkResult) || "" ) + ""
      })
    } catch (e) {
      this.setState({
        result: "Error"
      })
    }
  };

  reset = () => {
    this.setState({
      result: ""
    })
  }

  backspace = () => {
    var checkResult = ''
    if (this.state.result.includes('error') || this.state.result.includes('Infinity')){
      this.setState({
        result: ""
      })
    } else {
      this.setState({
        result: this.state.result.slice(0, -1)
      })
    }
  };

  render() {
    return (
      <div className="divBody">
        <div className="calcBody">
          <h1 className="calcTitle">Calculator</h1>
          <ResultComponent result={this.state.result}/>
          <KeyPadController onClick={this.onClick}/>
        </div>
      </div>
    );
  }
}

export default Calculator;