# Sprint 3 Planning
## Goal:
- Our goal for this sprint is to finalize the basics of our web application. This includes making our website dynamic and having a final theme for the user interface. For this sprint, we will also continue working on the mobile application and implementing the basic functions of the application.

## User stories for this sprint will be (Along with subtasks if any):
- Dynamic pages
  - Edit Home Page
  - Edit Course Page
  - Update Home page UI
  - Update Course page UI
- Deadlines
- Calender
- Graphing the data
- Calculator
  - Creating the UI
  - Implement the basic functions
- Mobile UI
- Mobile connections
  - Enable google login
- Mobile User Data
- Mobile basic functions
  - Create New Assignments
  - Create New Courses
  - Write to database
- We chose these user stories for our sprint 3 because for mobile application user stories, these are all the basic and main point of our application. Once we are finished these user stories, we can continue to polish and add more features. For the web application, these user stories will finalize the basics of our application and include some of the extra features that we as the group came up with.

## Participants:
- Haodong Mai
  - Haodong will work on the deadlines and the mobile user data. He will also be learning how how to develope an android application.
- Ze Chen
  - Ze will work on graphing the data, and helping with user interfaces of both the web application and mobile application
- Yu Heng Su
  - Yu Heng will be working on dynamic pages, mobile basic functions as well as the mobile connection. He will also help out with anyone that needs help with the user interface.
- Tya Jubandhu
  - Tya will mainly focus on implementing the calculator. 
- Evan Gilchrist
  - Evan will be responsible for implementing the calender.
- Brendan Maclean
  - Brendan will be focus on creating the mobile application's user interface, and helping others if they have any troubles with the android development

## Team Capacity
- Number of ideal days we should spend working on the application for this sprint is roughly 7-8 days per team member, since during this sprint, there is an increase amount of sick people. This should allows any team members who gets sick to rest and recover.
- So our overall team capacity would be:
  - 9 * 6 = 48
  - So our team capacity is roughly 48
