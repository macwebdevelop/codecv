import React from 'react';
import {addNotes, getNotes, firebase, auth, deleteNote} from '../databaseController/firebase.js';

export default class Notes extends React.Component {
	constructor(code) {
		super();
		this.handleFocus = this.handleFocus.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.handleKeypress = this.handleKeypress.bind(this);
		this.handleBlur = this.handleBlur.bind(this);
		this.handleClick = this.handleClick.bind(this);

		this.helperspan = null; // is set via ref
		
		this.state = {
			content_add: "Add Notes",
			myItems: [],
        };
        this.lastId = 0;
        this.courseCode = code;
	}


	handleFocus() {
		this.setState({ content_add: "" });
	}
	
	handleChange(event) {
        const usr_input = event.target.value;
        if (usr_input.length <= 500){
            this.setState({ content_add: usr_input });
        }
	}

	handleKeypress(event) {
		if (event.key === "Enter") {
            var user = firebase.auth().currentUser;
            if (user){
              console.log("user presist as", user.email);
            }

			var currentcontent = this.state.content_add.trim();
			if (!currentcontent) {
				return; 
            }
            addNotes(this.courseCode, currentcontent);
            this.updateNotes(currentcontent);


		}
    }
    
    updateNotes(Note){
        var newArray = this.state.myItems;
        newArray.push({
            id: ++this.lastId, 
            content: Note, 
        });
        this.setState({
            myItems: newArray,
            content_add: "",
        });
    }

	handleBlur() {
		this.setState({ content_add: "Add Notes"});
	}

	handleClick(e) {
        const idToRemove = Number(e.target.dataset["item"]);
		const newArray = this.state.myItems.filter((listitem) => {
            if(listitem.id == idToRemove){
                deleteNote(this.courseCode,listitem.content);
            }
            return listitem.id !== idToRemove
        });
        this.setState({ myItems: newArray });
	}

	makeAddedList() {
		
		const elements =  this.state.myItems.map((listitem) => (
            <li className="notesList"
                key={listitem.id}
                onClick={this.handleClick}
                data-item={listitem.id}
			>
				{listitem.content}
			</li>
		));
		return elements

    }
    componentDidMount(){
        const {code} = this.props.code;
        console.log(code);
        this.courseCode = code;
        auth.onAuthStateChanged(async (user) => {
          if (user) {
            this.setState({ user });
            await getNotes(user.email, code)
            .then(result => {
                if (result != null){
                    for (var i = 0; i < result.length; i ++){
                        this.updateNotes(result[i]["Note"]);
                        this.setState({ content_add: "Add Notes "});
                    }
                }
              })
          } 
        });
    }

	render() {
		return (
			<div className="notesDiv">
				{this.makeAddedList()}	
			<input
					className="notesInput"
					type="text"
					name="initvalue"
					autoComplete="off"
					onFocus={this.handleFocus}
					onChange={this.handleChange}
					onKeyPress={this.handleKeypress}
					onBlur={this.handleBlur}
					value={this.state.content_add}
				/>

				<span id="helperSpan" ref={el => (this.helperspan = el)}>
					{this.state.content_add}
				</span>

			</div>
		);
	}
}
