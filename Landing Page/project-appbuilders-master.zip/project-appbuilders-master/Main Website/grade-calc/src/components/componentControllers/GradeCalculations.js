import {updateGrade, updateProgress, getUserAssignments, changeCourseStatus, getCourseInfo} from '../databaseController/firebase.js'
import {firebase} from '../databaseController/firebase.js';

export function examGrade(examWeighting, courseCode) {
    var user = firebase.auth().currentUser;
    if (user){
      console.log("user presist as", user.email);
    }
    return getCourseInfo(user.email, courseCode)
    .then (course => {
        return getUserAssignments(user.email, courseCode)
        .then(result => {
            var currentGrade = 0;
            for (var i=0; i<result.length; i++){
                if (result[i].Completed)
                {
                    //Multiply the grade of the assignments by their weight and add it to a total
                    var weight = result[i].Weighting / 100 ;
                    currentGrade += result[i].Grade * weight;
                }
            }
            //Calculates the grade they need on the exam
            examWeighting /= 100;
            return (course[0]["Goal"] - currentGrade) / examWeighting;
        })
    })
}

export async function updateCourse(courseCode){
    var user = firebase.auth().currentUser;
    if (user){
      console.log("user presist as", user.email);
    }
    let cur_grade = 100;
    let marks_lost = 0;
    let updatedProgress = 0;
    await getUserAssignments(user.email, courseCode)
    .then(async result => {
        for (var i=0; i<result.length; i++){
            if (result[i].Completed)
            {
                //Calculate the current course grade as well as the current progress using the weighting
                var grade = parseInt((result[i]["Grade"] / result[i]["Total Grade"]) * 100);
                var mark = 100 - grade;
                var weight = result[i].Weighting / 100 ;
                marks_lost += (mark * weight);
                updatedProgress += result[i].Weighting;
            }
        }
        //Update the course grade and progress
        cur_grade -= marks_lost;
        await updateGrade(cur_grade, courseCode);
        await updateProgress(updatedProgress, courseCode);
        if(updatedProgress === 100)
        {
            await changeCourseStatus(true, courseCode);
        }
        // setTimeout(function() {window.location.reload(false);}, 1000);
    })
}

export function gpaCalculator(courses){
    let grade = 0;
    let gpa = 0;
    let count = 0;
    for (var i = 0; i < courses.length; i ++)
    {
        if (courses[i].Completed){
            count ++;
            grade += parseInt(courses[i]["Grade"]);
        }
    }
    grade /= count;
    if (grade >= 85){
        gpa = 4.0;
    }
    else if (grade >= 80){
        gpa = 3.7;
    }
    else if (grade >= 77){
        gpa = 3.3;
    }
    else if (grade >= 73){
        gpa = 3.0;
    }
    else if (grade >= 70){
        gpa = 2.7;
    }
    else if (grade >= 67){
        gpa = 2.3;
    }
    else if (grade >= 63){
        gpa = 2.0;
    }
    else if (grade >= 60){
        gpa = 1.7;
    }
    else if (grade >= 57){
        gpa = 1.3;
    }
    else if (grade >= 53){
        gpa = 1.0;
    }
    else if (grade >= 50){
        gpa = 0.7;
    }
    return gpa.toFixed(1);
}