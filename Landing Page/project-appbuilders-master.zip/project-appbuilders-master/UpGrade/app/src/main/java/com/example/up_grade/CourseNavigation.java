package com.example.up_grade;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CourseNavigation extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private Button signOutButton, assignmentButton, courseButton;
    private TextView greetings;
    private firebaseController controller = new firebaseController();
    private  String TAG = "CourseNavigationActivity";

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_navigation);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        mAuth = FirebaseAuth.getInstance();
        greetings = findViewById(R.id.greeting);

//        signOutButton = findViewById(R.id.sign_out_button);
//        assignmentButton = findViewById(R.id.createAssignments);
//        courseButton = findViewById(R.id.createCourses);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        String personEmail = account.getEmail();
        String userName = account.getDisplayName();
        String greetText = "Welcome! " + userName;
        greetings.setText(greetText);
        Log.w(TAG,"email is " + personEmail);

        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        final Context coursePageGenerate = this;

        controller.getUserCourses(personEmail, new callBack() {
            @Override
            public void onCallBack(List<Map> data) {
                ArrayList<String> courseCode = new ArrayList<>();
                for(Map course:data) {
                    Log.w(TAG, "Course code is " + course.get("Course Code"));
                    courseCode.add((String) course.get("Course Code"));
                }

                Log.w(TAG,courseCode.toString());

                // specify an adapter (see also next example)
                mAdapter = new courseTabAdapter(courseCode, coursePageGenerate);
                recyclerView.setAdapter(mAdapter);
            }
        });

//        signOutButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                mAuth.signOut();
//                updateUI();
//                Toast.makeText(CourseNavigation.this,"You are Logged Out",Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        assignmentButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                addAssignmentUI();
//            }
//        });
//
//        courseButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                addCourseUI();
//            }
//        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_coursenavigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.sign_out_button:
                mAuth.signOut();
                updateUI();
                Toast.makeText(this,"You are Logged Out",Toast.LENGTH_SHORT).show();
                return true;
            case R.id.newCourse:
                Intent intent = new Intent(this,CourseCreation.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void addAssignmentUI(){
        Intent intent = new Intent(this,AssignmentCreation.class);
        startActivity(intent);
    }

    private void addCourseUI(){
        Intent intent = new Intent(this,CourseCreation.class);
        startActivity(intent);
    }

    private void updateUI(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
