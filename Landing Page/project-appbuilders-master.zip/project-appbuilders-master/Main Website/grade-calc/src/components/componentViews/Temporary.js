
import React from 'react';

// import Calendar from 'react_google_calendar'
import Calendar from 'react-calendar';

// const calendar_configuration = {
//     api_key: 'AIzaSyCejAqy6-WRmN6lkAEZu7pNQcVADybHiRY',
//     calendars: [
//       {
//         name: 'appbuilders',
//         url: '17uj8t0i20rg6rpkjo938a6c2s@group.calendar.google.com'
//       }
//     ],
//     dailyRecurrence: 700,
//     weeklyRecurrence: 500,
//     monthlyRecurrence: 20
// }
//This is just a temporary file for the create course button, will remove once we finish home page
class Temporary extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      events: []
    };
  }
  
  render() {
    return (

      <div>
        <div>
          {/* <Calendar
            events={this.state.events}
            config={calendar_configuration} /> */}
            <Calendar locale="en"/>
        </div>
      </div>
    );

  }
}

export default Temporary;
