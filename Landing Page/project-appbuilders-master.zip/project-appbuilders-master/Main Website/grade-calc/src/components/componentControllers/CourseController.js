
import { Component } from 'react';
import { deleteAssignment, changeAssignmentStatus} from '../databaseController/firebase.js';
import { updateCourse } from '../componentControllers/GradeCalculations'
export default class CourseController extends Component{
	constructor(props)
	{
		super(props);
	}
	
	courseInfo(course)
	{
		//Loops through the current course info and displays all the main informations
		//Such as, professor, ta, progression, status
		let grid = document.querySelector('.infoContainer');
		var status = document.createElement("p");
		var goal = document.createElement("p");
		var progression = document.createElement("p");
		var professor = document.createElement("p");
		var teacherAssistant = document.createElement("p");

		status.className = "courseText";
		goal.className = "courseText";
		progression.className = "courseText";
		professor.className = "courseText";
		teacherAssistant.className = "courseText";

		professor.innerHTML = "Professor: " + course[0]["Professor"];
		teacherAssistant.innerHTML = "Teacher Assistant: " + course[0]["Teacher Assistant"];

		if (course[0].Completed){
			progression.innerHTML = "Progression: 100%";
			status.innerHTML = "Status: Completed";
		}
		else{
			progression.innerHTML = "Progression: " + course[0]["Progress"] + "%";
			goal.innerHTML = "Course Goal: " + course[0]["Goal"] + "%"; 
			status.innerHTML = "Status: Attending";
		}

		grid.appendChild(status);
		grid.append(goal);
		grid.appendChild(progression);
		grid.appendChild(professor);
		grid.appendChild(teacherAssistant);
	}
	courseCode(code)
	{
		let grid = document.querySelector('.infoContainer');
		var courseCode = document.createElement("h1");
		courseCode.className = "courseTitle";
		courseCode.innerHTML = code;

		grid.appendChild(courseCode);
	}

	courseGrade(course)
	{
		//Displays the current grade
		var courseGrade = document.getElementsByClassName("courseGrade")
		for (var i = 0; i < courseGrade.length; i++) {
			courseGrade[i].innerHTML = "Current Grade: " + course[0]["Grade"] + "%";
		  }

	}
	redirectGraph(assignments, code){
		let grid = document.querySelector(".courseGrade");
		var a = document.createElement("a");
		a.innerHTML = "   📈";
		a.className = "graphIcon";
		a.onclick = function(){
			console.log("Directing to graph");
			this.props.history.push({pathname: '/graph',state: {name: this.getName(assignments), grade:this.getGrade(assignments), code: code}})
			// this.props.history.push({pathname: '/course'});
			
			return false;
		}.bind(this);
		grid.append(a);
	}
	getName(assignments)
	{
		var list_of_names = [];
		if(assignments != null){
			var i;
			for (i=0; i<assignments.length; i++){
				if(assignments[i].Completed)
				{
					list_of_names.push(assignments[i]["Name"]);
				}
			}
		}
		return list_of_names;
	}

	getGrade(assignments)
	{
		var list_of_grades = [];
		if(assignments != null){
			var i;
			for (i=0; i<assignments.length; i++){
				if(assignments[i].Completed)
				{
					let grade = (assignments[i]["Grade"] / assignments[i]["Total Grade"])*100;
					list_of_grades.push(grade);
				}
			}
		}
		return list_of_grades;
	}
	courseView(assignments, code)
	{
		//Displays all the assignment informations
		if(assignments != null){
			var i;
			for (i=0; i<assignments.length; i++){

				let name = assignments[i]["Name"];
				let totalGrade = assignments[i]["Total Grade"];

				var assignmentName = document.createElement("p");
				var assignmentWeight = document.createElement("p");
				var assignmentGrade = document.createElement("p");
				var assignmentGoal = document.createElement("p");
				var deleteButton = document.createElement("p");
				var finishedButton = document.createElement("p");
				var assignmentDeadline = document.createElement("p");


				deleteButton.innerHTML = "X";

				assignmentName.innerHTML = assignments[i]["Name"];
				assignmentWeight.innerHTML = assignments[i]["Weighting"] + "%";
				assignmentGoal.innerHTML = assignments[i]["Goal"] + "%";

				//Creates the delete and update button
				deleteButton.onclick = async function(e){
					e.stopPropagation();
					await deleteAssignment(code, name);
					updateCourse(code);
					
				}

				finishedButton.onclick = async function(e)
				{
					e.stopPropagation();
					let input = prompt("Grade Recieved out of " + totalGrade)
					if(input != null){
						console.log(input);
						await changeAssignmentStatus(code, name, true, parseInt(input));
						updateCourse(code)
					}
				}

				deleteButton.id = "optionButton";
				finishedButton.id = "optionButton";

				//If the assignment is an exam, display it in a special section
				if(assignments[i]["Name"] == "Exam")
				{
					let grid = document.querySelector('.examGrid');
					var calculatedGoal = document.createElement("p");

					calculatedGoal.innerHTML = assignments[i]["Calculated Goal"] + "%";
					
					let examTitle = document.getElementsByClassName("examTitle");
					let examInfo = document.getElementsByClassName("examInfo");
			  
					for (var j = 0; j < examTitle.length; j++) {
					  examTitle[j].style = "display: show";
					}
			  
					for (var k = 0; k < examInfo.length; k++) {
					  examInfo[k].style = "display: show";
					}
					
					if (assignments[i].Completed)
					{
						let grade = Math.floor((assignments[i]["Grade"] / assignments[i]["Total Grade"])*100);
						assignmentGrade.innerHTML = grade + "%";
					}
					else{
						assignmentGrade.innerHTML = "N/A";
					}

					assignmentName.className = "examInfo";
					assignmentWeight.className = "examInfo";
					assignmentGrade.className = "examInfo";
					assignmentGoal.className = "examInfo";
					calculatedGoal.className ="examInfo";
					deleteButton.className ="examInfo";

					finishedButton.innerText = "✔";
					finishedButton.className = "examInfo";
					
					grid.appendChild(assignmentName);
					grid.appendChild(assignmentWeight);
					grid.appendChild(assignmentGrade);
					grid.appendChild(assignmentGoal);
					grid.appendChild(calculatedGoal);
					grid.appendChild(deleteButton);
					grid.appendChild(finishedButton);
				}
				else {
					//Otherwise it is a normal assignment, and display it in the assignment grid
					let grid = document.querySelector('.assignmentGrid');
					if(assignments[i].Completed)
					{
						//If completed, only display it when the completed button is selected
						let grade = Math.floor((assignments[i]["Grade"] / assignments[i]["Total Grade"])*100);
						assignmentGrade.innerHTML = grade + "%";
						assignmentDeadline.innerHTML = "N/A";
						
						assignmentName.className = "pastAssignment";
						assignmentWeight.className = "pastAssignment";
						assignmentGrade.className = "pastAssignment";
						assignmentGoal.className = "pastAssignment";
						assignmentDeadline.className = "pastAssignment";

						deleteButton.className ="pastAssignment";

						finishedButton.innerText = " ";
						finishedButton.className = "pastAssignment";
					}
					else
					{
						assignmentGrade.innerHTML = "N/A";
						var deadline = assignments[i]["Deadline"];
						assignmentDeadline.innerHTML = deadline.toDate().toLocaleDateString();

						assignmentName.className = "currentAssignment";
						assignmentWeight.className = "currentAssignment";
						assignmentGrade.className = "currentAssignment";
						assignmentGoal.className = "currentAssignment";
						assignmentDeadline.className = "currentAssignment";

						deleteButton.className ="currentAssignment";

						
						finishedButton.innerText = "✔";
						finishedButton.className = "currentAssignment";

					}

					grid.appendChild(assignmentName);
					grid.appendChild(assignmentWeight);
					grid.appendChild(assignmentGrade);
					grid.appendChild(assignmentGoal);
					grid.appendChild(assignmentDeadline);
					grid.appendChild(deleteButton);
					grid.appendChild(finishedButton);
				}
			}
		}
		else
		{
			//No assignment/exams
			let grid = document.querySelector('.assignmentGrid');
			var pastError = document.createElement("p");
			var currentError = document.createElement("p");
			
			pastError.className = "pastAssignment";
			pastError.style = "font-syle:italic";
			pastError.innerHTML = "No assignments available"

			currentError.className = "currentAssignment";
			currentError.style = "font-syle:italic";
			currentError.innerHTML = "No assignments available"

			grid.appendChild(pastError);
			grid.appendChild(currentError);
		}
	}
}
