 Tools/Techniques/Conventions that worked:
 
 Our group found that some of the tools that worked best for us were
Firebase/Firestore, Jira, Github, NodeJS and ReactJS.  We found that
these tools were reliable and allowed us to build and scale our applications
easily and productively.  Jira and Github were particularly useful in
regards to the Agile methodology that we used, as it allowed us to manage 
our individual User Stories by assigning them and keeping track of how the
implementations of each feature was progressing, while also ensuring independance
between group members for each sprint.  Firebase/Firestore was a very adaptable 
database system, as it was compatible with both Javascript programming for the web
application and with Java for the android application development.  Finally, NodeJS
and ReactJS were very versatile frameworks that allowed for the web application
to be built very efficiently and compile and execute effectively.
Also, while it is not a particularly unique technique or convention, we found that
consistent communication over applications like Microsoft Teams and Discord to
improve the workflow immensely and get assistance from each other for any errors 
or issues that we might experience.

Tools/Techniques/Conventions that didn't work well:

The primary tool that was less efficient and slowed our work down the most
was Android Studio for building our mobile application.  While AS is a
powerful toolset for constructing applications, it is not without its faults
and complications when working with groups.  Group members had to be cautious
about which layout format they used when building their activity screens.  When
the Constraint Layout was used for arranging elements, issues arose when the group
members files would be pushed to the Git repository and be subsequently pulled
by another member, the elements would no longer retain their positions and would 
instead be found to stack themselves in the same location at the top right corner
of the screen build mock-ups.

Redesigning the process

There isn't much different we would do as a group, as we worked fairly efficiently 
with each other and reported problems as they occurred.  We might consider a different
resource or tool for building the android application, though in the end AS was able 
to help us deliver a viable product.  Had we been working for a longer period of time,
our group might have discussed increased available functionality for the android 
application, and the possibility of learning about and building an iOS/Swift version
of the mobile application for iPhones.  Increased functionality of the android application
would include ideas such as bringing the graph, notes, and exam grade calculator features 
of the web application to the mobile interface so that users might be able to access even
more of the applications utility from mobile and web equally.
