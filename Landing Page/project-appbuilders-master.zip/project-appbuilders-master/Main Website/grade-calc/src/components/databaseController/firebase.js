export const firebase = require('firebase/app')

require("firebase/auth");
require("firebase/firestore");

var firebaseConfig = {
  apiKey: "AIzaSyADgf3-YaxKssgLTBBNnaP_wkliBD3-lMc",
  authDomain: "project-app-builders-utm.firebaseapp.com",
  databaseURL: "https://project-app-builders-utm.firebaseio.com",
  projectId: "project-app-builders-utm",
  storageBucket: "project-app-builders-utm.appspot.com",
  messagingSenderId: "444041330162",
  appId: "1:444041330162:web:e6931670f59cf41cc2ff6b",
  measurementId: "G-9X8GX7K8J5"
};

try {
  firebase.initializeApp(firebaseConfig);
} catch (err) {
  if (!/already exists/.test(err.message)) {
    console.error("Firebase initialization error", err.stack);
  }
}

export const provider = new firebase.auth.GoogleAuthProvider();
export const auth = firebase.auth();
export const db = firebase.firestore();

export default firebase;

// grabs every document in the collection 'users' and prints to console
export function printUsers() {
  var msg = '';
  db.collection('users').get()
    .then((snapshot) => {
      snapshot.forEach((doc) => {
        console.log(doc.id, '=>', doc.data());
      });
      return msg;
    })
    .catch((err) => {
      console.log('Error getting documents ', err);
    });
}

// register a user
export function registerUser(username, password, firstName, lastName, emailAddress) {

  firebase.auth().createUserWithEmailAndPassword(emailAddress, password).catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    console.log(errorCode, errorMessage);
    window.location.href='/';
  });
  
  var uid;

  auth.onAuthStateChanged((user)=>{
    if(user){
        uid = user.uid;
        console.log("uid is", emailAddress);
        let userRef = db.collection('users').doc(emailAddress);
    
        let setUser = userRef.set({
        'Username': username,
        'Password': password,
        'First Name': firstName,
        'Last Name': lastName,
        'Email': emailAddress
      });
      }else{
        console.log("user document not created");
      }
  });
  
}

export function verifyUserDataWithGoogle(currentuser){
  var userName, userEmail, uid;
  
  uid = currentuser.uid;
  currentuser.providerData.forEach(function (profile) {
    userName =  profile.displayName;
    userEmail = profile.email;
    //console.log("  Photo URL: " + profile.photoURL);
  });
   
  var userDataRef = db.collection('users').doc(userEmail);

  var setWithMerge = userDataRef.set({
  'Username': userName,
  'Password': '',
  'First Name': '',
  'Last Name': '',
  'Email': userEmail
  }, { merge: true });

}

// add a course
export async function addCourse(courseCode, courseName, grade, goal, completed, progress, prof ,ta) {
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  let courseRef = db.collection('users').doc(user.email).collection('Courses').doc();

  let setCourse = await courseRef.set({
    'Course Code': courseCode,
    'Course Name': courseName,
    'Completed': completed,
    'Grade': grade,
    'Goal': goal,
    'Progress': progress,
    'Professor': prof,
    'Teacher Assistant': ta
  })
  setTimeout(function() {window.location.reload(false);}, 1000);
}

export async function updateGrade(updatedGrade, courseCode){
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(result =>
    {
      let courseRef = db.collection('users').doc(user.email).collection('Courses').doc(result[0]);
      courseRef.update({
        Grade: updatedGrade})
    }
  )
}

export async function updateProgress(updatedProgress, courseCode){
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(result =>
    {
      let courseRef = db.collection('users').doc(user.email).collection('Courses').doc(result[0]);
      courseRef.update({
        Progress: updatedProgress})
    }
  )
}

export async function getCourseID(courseCode)
{
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  let userCoursesRef = db.collection('users').doc(user.email).collection('Courses');
  return userCoursesRef.where("Course Code", "==", courseCode).limit(1).get()
    .then(snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents.');
        return null;
      }
      var docId = [];
      snapshot.forEach(doc => {
        docId.push(doc.id);
      })
      return docId;
    })
    .catch(err => {
      console.log("Error getting document", err)
      return -1
    })
}

export async function getAssignmentId(courseId, assignmentName)
{
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  let userCoursesRef = db.collection('users').doc(user.email).collection('Courses').doc(courseId).collection('Assignments');
  return userCoursesRef.where("Name", "==", assignmentName).limit(1).get()
    .then(snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents.');
        return null;
      }
      var docId = [];
      snapshot.forEach(doc => {
        docId.push(doc.id);
      })
      return docId;
    })
    .catch(err => {
      console.log("Error getting document", err)
      return -1
    })
}

export async function deleteAssignment(courseCode, assignmentName)
{
  console.log("Deleteing: ", assignmentName);
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(async result =>
    {
      await getAssignmentId(result[0], assignmentName)
      .then (async assignmentResult =>
        {
            let assignmentRef = await db.collection('users').doc(user.email).collection('Courses').doc(result[0]).collection('Assignments').doc(assignmentResult[0]).delete()
            .then(function() {
              console.log("Document successfully deleted!");
            }).catch(function(error) {
              console.error("Error removing document: ", error);
            });
        })
    }
  )
  setTimeout(function() {window.location.reload(false);}, 1000);
}
export async function deleteCourse(courseCode)
{
  console.log("Deleteing: ", courseCode);
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(async result =>
    {
      let courseRef = await db.collection('users').doc(user.email).collection('Courses').doc(result[0]).delete()
      .then(function() {
        console.log("Document successfully deleted!");
      }).catch(function(error) {
        console.error("Error removing document: ", error);
      });
    }
  )
  setTimeout(function() {window.location.reload(false);}, 1000);
}
export async function addAssignment(courseCode, type, name, grade, goal, gradeTotal, weight, completed, calculatedGoal, deadline) {
  //Need to add a course doc
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(async result =>
    {
      let assignmentRef = db.collection('users').doc(user.email).collection('Courses').doc(result[0]).collection('Assignments').doc();
      let setAssignment = await assignmentRef.set({
        "Completed": completed,
        "Goal": goal,
        "Grade": grade,
        "Name": name,
        "Total Grade": gradeTotal,
        "Type": type,
        "Weighting": weight,
        "Calculated Goal": calculatedGoal,
        'Deadline': new Date(deadline)
    })
    setTimeout(function() {window.location.reload(false);}, 1000);
  })
}

export async function addNotes(courseCode, note) {
  //Need to add a course doc
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(async result =>
    {
      let noteRef = db.collection('users').doc(user.email).collection('Courses').doc(result[0]).collection('Notes').doc();
      let setAssignment = await noteRef.set({
        "Note": note
    })
  })
}

export function getNotes(userDocId, courseCode) {
  let userCoursesRef = db.collection('users').doc(userDocId).collection('Courses');
  return userCoursesRef.where("Course Code", "==", courseCode).limit(1).get()
    .then(snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents');
        return null;
      }
      var courseId = null;
      snapshot.forEach(doc => {
        courseId = doc.id;
      })
      let assignmentRef = db.collection('users').doc(userDocId).collection('Courses').doc(courseId).collection('Notes');
      return assignmentRef.get()
        .then(snapshot => {
          if (snapshot.empty) {
            console.log('No matching documents.');
            return null
          }
          var list_of_notes = []
          snapshot.forEach(doc => {
            var noteInfo = {
              "Note": doc.get("Note")
            }
            list_of_notes.push(noteInfo);
          })
          return list_of_notes;
        })
    })
    .catch(err => {
      console.log("Error getting document", err)
      return -1
    })
}

export async function getNoteId(courseId, note)
{
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  let userCoursesRef = db.collection('users').doc(user.email).collection('Courses').doc(courseId).collection('Notes');
  return userCoursesRef.where("Note", "==", note).limit(1).get()
    .then(snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents.');
        return null;
      }
      var docId = [];
      snapshot.forEach(doc => {
        docId.push(doc.id);
      })
      return docId;
    })
    .catch(err => {
      console.log("Error getting document", err)
      return -1
    })
}

export async function deleteNote(courseCode, note)
{
  console.log("Deleteing: ", note);
  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(async result =>
    {
      await getNoteId(result[0], note)
      .then (async noteResult =>
        {
            let assignmentRef = await db.collection('users').doc(user.email).collection('Courses').doc(result[0]).collection('Notes').doc(noteResult[0]).delete()
            .then(function() {
              console.log("Document successfully deleted!");
            }).catch(function(error) {
              console.error("Error removing document: ", error);
            });
        })
    }
  )
}



// return user info as a dictionary (contained in a document) given document id
// returns null if document not found, returns -1 on failure
export function getUserInfo(userDocId) {
  let userRef = db.collection('users').doc(userDocId);
  let getUserDoc = userRef.get()
    .then(doc => {
      if (!doc.exists) {
        console.log('No such document!');
        return null
      }
      var doc_info = {
        "Email": doc.get("Email"),
        "First Name": doc.get("First Name"),
        "Last Name": doc.get("Last Name"),
        "Username": doc.get("Username"),
        "Password": doc.get("Password")
      }
      return doc_info;
    })
  .catch(err => {
    console.log('Error getting document', err);
    return -1;
  })
}

// get user's course collection given document id
// collection in the form of a list of dictionaries
// returns null if no courses found, returns -1 on failure
export function getUserCourses(userDocId) {
  let userCoursesRef = db.collection('users').doc(userDocId).collection('Courses');
  return userCoursesRef.orderBy('Course Code').get()
    .then(snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents.');
        return null;
      }
      var list_of_courses = [];
      snapshot.forEach(doc => {
        var course_dict = {
          "Completed": doc.get("Completed"),
          "Course Code": doc.get("Course Code"),
          "Course Name": doc.get("Course Name"),
          "Grade": doc.get("Grade"),
          "Goal": doc.get("Goal"),
          "Progress": doc.get("Progress"),
          "Professor": doc.get("Professor"),
          "Teacher Assistant": doc.get("Teacher Assistant"),
        }
        list_of_courses.push(course_dict);
      })

      return list_of_courses;
    })
    .catch(err => {
      console.log('Error getting document', err);
      return null;
    })
}

// get user's assignments for a single course given user id and course code
// collection in the form of list of dictionaries
// returns null if not found, returns -1 on error
export function getUserAssignments(userDocId, courseCode) {
  let userCoursesRef = db.collection('users').doc(userDocId).collection('Courses');
  return userCoursesRef.where("Course Code", "==", courseCode).limit(1).get()
    .then(snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents');
        return null;
      }
      var courseId = null;
      snapshot.forEach(doc => {
        courseId = doc.id;
      })
      let assignmentRef = db.collection('users').doc(userDocId).collection('Courses').doc(courseId).collection('Assignments');
      return assignmentRef.get()
        .then(snapshot => {
          if (snapshot.empty) {
            console.log('No matching documents.');
            return null
          }
          var list_of_assignments = []
          snapshot.forEach(doc => {
            var assignment_info = {
              "Completed": doc.get("Completed"),
              "Goal": doc.get("Goal"),
              "Grade": doc.get("Grade"),
              "Name": doc.get("Name"),
              "Total Grade": doc.get("Total Grade"),
              "Type": doc.get("Type"),
              "Weighting": doc.get("Weighting"),
              "Calculated Goal": doc.get("Calculated Goal"),
              "Deadline": doc.get("Deadline")
            }
            list_of_assignments.push(assignment_info);
          })
          return list_of_assignments;
        })
    })
    .catch(err => {
      console.log("Error getting document", err);
      return -1;
    })
}

export function getCourseInfo(userDocId, courseCode) {
  let userCoursesRef = db.collection('users').doc(userDocId).collection('Courses');
  return userCoursesRef.where("Course Code", "==", courseCode).limit(1).get()
    .then(snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents.');
        return null;
      }
      var list_of_courses = [];
      snapshot.forEach(doc => {
        var course_dict = {
          "Completed": doc.get("Completed"),
          "Course Code": doc.get("Course Code"),
          "Course Name": doc.get("Course Name"),
          "Grade": doc.get("Grade"),
          "Goal": doc.get("Goal"),
          "Progress": doc.get("Progress"),
          "Professor": doc.get("Professor"),
          "Teacher Assistant": doc.get("Teacher Assistant")
        };
        list_of_courses.push(course_dict);
      })
      return list_of_courses;
    })
    .catch(err => {
      console.log("Error getting document", err);
      return -1;
    })
}

// grabs all incompleted assignments from a specific user
// within a range of notifRange days
export function getUpcomingAssignments(userDocId) {
  const notifRange = 7 // range in days to return assignments
  let start = new Date();
  let end = new Date();
  start.setDate(start.getDate());
  end.setDate(end.getDate() + notifRange);

  let ref = db.collectionGroup('Assignments')
    .where('Completed', '==', false)
    .where('Deadline', '>', start)
    .where('Deadline', '<', end)
    .orderBy('Deadline', 'asc');

  return ref.get()
    .then(async snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents.');
        return;
      }
      var upcoming_assignments = [];
      snapshot.forEach(async doc => {
        upcoming_assignments.push(deadlineHelper(doc));
      })
      console.log(upcoming_assignments);
      console.log(upcoming_assignments.length);
      return Promise.all(upcoming_assignments);
    })
    .catch(err => {
      console.log('Error getting documents', err);
      return -1;
    });
}

export function getAllDeadlines(userDocId) {
  let start = new Date();
  start.setDate(start.getDate());

  let ref = db.collectionGroup('Assignments')
    .where('Completed', '==', false)
    .where('Deadline', '>', start)
    .orderBy('Deadline', 'asc');

  return ref.get()
    .then(async snapshot => {
      if (snapshot.empty) {
        console.log('No matching documents.');
        return;
      }
      var upcoming_assignments = [];
      snapshot.forEach(async doc => {
        upcoming_assignments.push(deadlineHelper(doc));
      })
      console.log(upcoming_assignments);
      console.log(upcoming_assignments.length);
      return Promise.all(upcoming_assignments);
    })
    .catch(err => {
      console.log('Error getting documents', err);
      return -1;
    });
}

export async function deadlineHelper(doc){
  return await doc.ref.parent.parent.get()
    .then(parent => {

      var course_code = parent.get("Course Code");
      var assignment_dict = {
        "Completed": doc.get("Completed"),
        "Goal": doc.get("Goal"),
        "Grade": doc.get("Grade"),
        "Name": doc.get("Name"),
        "Total Grade": doc.get("Total Grade"),
        "Type": doc.get("Type"),
        "Weighting": doc.get("Weighting"),
        "Calculated Goal": doc.get("Calculated Goal"),
        "Deadline": doc.get("Deadline")
      }
      const pair = [course_code, assignment_dict]
      return pair;
  });
}

//change assignment staus 
export async function changeAssignmentStatus(courseCode, assignmentName, status, grade){

  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(async result =>
    {
      await getAssignmentId(result[0], assignmentName)
      .then (async assignmentResult =>
        {
            let assignmentRef = db.collection('users').doc(user.email).collection('Courses').doc(result[0]).collection('Assignments').doc(assignmentResult[0]);
            await assignmentRef.update({Completed: status,
                                  Grade: grade});
        })
    }
  )
  setTimeout(function() {window.location.reload(false);}, 1000);
  
}
//change course status 
export async function changeCourseStatus(status, courseCode){

  var user = firebase.auth().currentUser;
  if (user){
    console.log("user presist as", user.email);
  }
  await getCourseID(courseCode)
  .then(result =>
    {
      var courseRef = db.collection("users").doc(user.email).collection("Courses").doc(result[0]);
      courseRef.update({Completed: status});
    }
  )
  
}