//Do not remove this import
import React, { Component } from 'react';
import '../css/tutorial.css';
import HomePage from '../componentViews/pictures/homePage.png'
import coursePage from '../componentViews/pictures/coursePage.png'
//Any imports would go here

class Tutorial extends Component {
    //ANY BACK END CODE/FUNCTIONS WOULD GO HERE
	constructor(props) {
        super(props);
        this.images = [HomePage, coursePage];
        this.index = 0;
		this.state = {
            image: this.images[this.index]
          }
        this.nextImage = this.nextImage.bind(this);
        this.previousImage = this.previousImage.bind(this);
	}

    nextImage(){
        if (this.index != 1)
        {
            this.index ++;
            this.setState({
                image: this.images[this.index]
            })
        }

    }
    previousImage(){
        if (this.index != 0)
        {
            this.index --;
            this.setState({
                image: this.images[this.index]
            })
        }
    }
  render() {
    return (
        // FRONT END CODE GOES HERE
        <div className="tutorialContainer">
            <h1 className="tutorialTitle">Help</h1>
            <img className="tutorialPictures" src ={this.state.image}></img>
            <br></br>
            <button className="pictureButton" onClick={() => {this.previousImage()}}>{"<"}</button>
            <button className="pictureButton" onClick={() => {this.nextImage()}}>{">"}</button>
        </div>
    );
  }
}
export default Tutorial;