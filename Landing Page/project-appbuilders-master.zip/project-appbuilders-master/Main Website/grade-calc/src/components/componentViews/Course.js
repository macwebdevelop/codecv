//Do not remove this import
import React, { Component } from 'react';
//Any imports would go here
import '../css/CoursePageUI.css';
import { auth, getUserAssignments, getCourseInfo } from '../databaseController/firebase.js';
import CourseController from '../componentControllers/CourseController.js';
import NewAssignment from '../createItems/NewAssignment.js';
import CompletedAssignment from '../createItems/CompletedAssignment.js';
import Notes from '../createItems/Notes';
import Popup from "reactjs-popup";
import {Bar, Line, Pie} from 'react-chartjs-2';

class Course extends Component {
    //ANY BACK END CODE/FUNCTIONS WOULD GO HERE
    constructor(props)
    {
      super(props)
      this.courseCode = props.location.state;
      this.controller = new CourseController(props);
    }

    componentDidMount(){
      const { code } = this.props.location.state
      this.courseCode = code;
      auth.onAuthStateChanged(async (user) => {
        if (user) {
          this.setState({ user });
          //Displays the course information
          await getCourseInfo(user.email,code)
          .then (result=> {
            //Displays the course grade and other informations
            this.controller.courseGrade(result);
            this.controller.courseCode(code);
            this.controller.courseInfo(result);
          })
          //Displays the assignment information
          await getUserAssignments(user.email, code)
          .then(result => {
            this.controller.courseView(result, code);
            this.controller.redirectGraph(result, code);
            this.switchCurrent();
          })
        } 
        });
        this.hideExam();
    }

    hideExam(){
      let examTitle = document.getElementsByClassName("examTitle");
      let examInfo = document.getElementsByClassName("examInfo");
      for (var k = 0; k < examTitle.length; k++) {
        examTitle[k].style = "display: none";
      }

      for (var l = 0; l < examInfo.length; l++) {
        examInfo[l].style = "display: none";
      }
    }

    switchCurrent(){
      //Switching between current/paste assignment view
      let currentAssignment = document.getElementsByClassName("currentAssignment");
      let pastAssignment = document.getElementsByClassName("pastAssignment");

      for (var i = 0; i < currentAssignment.length; i++) {
        currentAssignment[i].style = "display: show";
      }
      for (var j = 0; j < pastAssignment.length; j++) {
        pastAssignment[j].style = "display: none";
      }
    }

    switchPast(){
      //Switching between current/paste assignment view
        let currentAssignment = document.getElementsByClassName("currentAssignment");
        let pastAssignment = document.getElementsByClassName("pastAssignment");
        for (var i = 0; i < currentAssignment.length; i++) {
          currentAssignment[i].style = "display: none";
        }
        for (var j = 0; j < pastAssignment.length; j++) {
          pastAssignment[j].style = "display: show";
        }
    }

  render() {
    return (
        // FRONT END CODE GOES HERE
      <article id="courses">
        <div className="grid-container" id="content">
          <div className="leftContainer">
            <div className="infoContainer"></div>
            <h1 className="noteTitle">Notes</h1>
            <Notes code={this.courseCode}/>
          </div>
          <div className="rightContainer">
            <hi className="courseGrade"></hi>
            <p ><button className="assignmentButton" onClick={() => {this.switchCurrent()}}>Current Assignments</button>
                <button className="assignmentButton" onClick={() => {this.switchPast()}}>Completed Assignments</button>
            </p>
            <div className="assignmentGrid">
              <p className="assignmentInfo">Name</p>
              <p className="assignmentInfo">Weight</p>
              <p className="assignmentInfo">Grade</p>
              <p className="assignmentInfo">Goal</p>
              <p className="assignmentInfo">Deadline</p>
              <p className="assignmentInfo">{" "}</p>
              <p className="assignmentInfo">{" "}</p>
            </div>
            <p className="examTitle">Exam</p>
            <div className="examGrid">
              <p className="examInfo">Name</p>
              <p className="examInfo">Weight</p>
              <p className="examInfo">Grade</p>
              <p className="examInfo">Personal Goal</p>
              <p className="examInfo">Calculated Goal</p>
              <p className="examInfo">{" "}</p>
              <p className="examInfo">{" "}</p>
            </div>
          </div>
        </div>
        
        <div className="courseCorner" style={{position: "fixed", bottom: "50px", right:"50px" , z: "999"}} >
          <li className="modalList">
                <Popup className="modal" modal trigger={<button className="assignmentButton">New Assignments +</button>}>
                <NewAssignment className="modal" code={this.courseCode}/>
                </Popup>
              </li>
          <li className="modalList">
                <Popup modal trigger={<button className="assignmentButton">Completed Assignment +</button>}>
                <CompletedAssignment code={this.courseCode}/>
                </Popup>
          </li>
			</div>
      </article>
    );
  }
}
export default Course;
