package com.example.up_grade;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;

public class CourseCreation extends AppCompatActivity  {
    private TextView courseName, courseCode, courseGrade, courseProf, courseTa;
    private Button submitButton;
    private FirebaseAuth mAuth;
    private Spinner spinner;
    private Switch completedSwitch;
    private String statusInput;
    private firebaseController controller = new firebaseController();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_creation);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        mAuth = FirebaseAuth.getInstance();

        courseName = findViewById(R.id.courseNameText);
        courseCode = findViewById(R.id.courseCodeText);
        courseGrade = findViewById(R.id.courseGradeText);
        courseProf = findViewById(R.id.courseProfText);
        courseTa = findViewById(R.id.courseTaText);
        submitButton = findViewById(R.id.courseSubmit);

//        spinner = findViewById(R.id.statusSpinner);
//        spinner.setOnItemSelectedListener(this);
//
//// Create an ArrayAdapter using the string array and a default spinner layout
//        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
//                R.array.statusArray, android.R.layout.simple_spinner_item);
//// Specify the layout to use when the list of choices appears
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//// Apply the adapter to the spinner
//        spinner.setAdapter(adapter);
//
        completedSwitch = findViewById(R.id.completed);
        completedSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    statusInput = "Completed";
                } else {
                    // The toggle is disabled
                    statusInput = "NotCompleted";
                }
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submit();
            }
        });
    }

    private void submit() {
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        //Need to change this to writing to database
        String personEmail = account.getEmail();
        int grade = 100;

        try {
            grade = Integer.parseInt(courseGrade.getText().toString());
        } catch(NumberFormatException nfe) {
            System.out.println("Could not parse " + nfe);
        }
        //Need to change this to write to database
        String nameInput = courseName.getText().toString();
        String codeInput = courseCode.getText().toString();
        String gradeInput = courseGrade.getText().toString();
        String profInput = courseProf.getText().toString();
        String taInput = courseTa.getText().toString();
        Log.d("CREATION", nameInput);
        Log.d("CREATION", codeInput);
        Log.d("CREATION", gradeInput);
        Log.d("CREATION", profInput);
        Log.d("CREATION", taInput);
        Log.d("CREATION", statusInput);

        controller.addCourse(personEmail, nameInput, codeInput, profInput, taInput, grade, statusInput );

        finish();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_coursecreation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.sign_out_button:
                mAuth.signOut();
                updateUI();
                Toast.makeText(this,"You are Logged Out",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateUI(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

}
