import React from 'react';
import Popup from "reactjs-popup";
import {addCourse} from '../databaseController/firebase.js'

export default class CompletedCourse extends React.Component {
    constructor() {
        super();
        this.state = {
          coursecode:'',
          coursename: '',
          grade:''
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this); 
      }

        handleChange(e) {
          this.setState({
            [e.target.name]: e.target.value
          });
        }

        handleSubmit(e) {
            e.preventDefault();
            addCourse(this.state.coursecode, this.state.coursename, parseInt(this.state.grade),100, true, 100, "N/A", "N/A");
            this.setState({
              coursecode:'',
              coursename: '',
              grade:''
            });
          }
    print(text){
        console.log(text);
    }
  render() {
    return (
        //This creates the popup form
        <Popup trigger = {<button className='contentButton'> Completed Course</button>} modaltrigger position = "left center">

            <div className="modal">
                <div className="modalContent">
                <div className="modalHeader"> Completed Course </div>
                <form className = "input" onSubmit = {this.handleSubmit.bind(this)}>
                    <input className = "inputForm" type="text" name="coursecode" placeholder="Course Code" onChange={this.handleChange} value={this.state.coursecode} />
                    <input className = "inputForm" type="text" name="coursename" placeholder="Course Name" onChange={this.handleChange} value={this.state.coursename} />
                    <input className = "inputForm" type="text" name="grade" placeholder="Grade" onChange={this.handleChange} value={this.state.grade} />
                    <button className = "submitButton">Submit</button>
                </form>
                </div>
            </div>

      </Popup>
    );
  }
}