# Sprint 1 Planning
## Goal:
- Our goal for this sprint is to complete the important user stories so we can get our base foundation done for our application

## User stories for this sprint will be (Along with subtasks):
- Login/Logout/Register
  - Create the front end for the Login and Register page
  - Connect the application to the database
- The ability to create either past/future assignments
  - Create temporary UI
  - Save the assignment information from the input
  - Generalize for future assignments
- The ability to add new courses
  - Create a temporary UI
  - Create completed courses
  - Create new courses
- The base templates for the web pages
  - Link up the web pages
  - Create temporary UI
  - Set up any installations needed
- The UI for home page and the course page
  - Create the basic foundation to work from
  - Retrieve data form the database
  - Create visuals for the data
- We chose these user stories for our sprint 1 because these are the user stories that would lay out the foundation of our application. After these user stories are completed, we should be able to easily add features to the application.

## Participants:
- Haodong Mai
  - Haodong will work together with Ze on the user story that will create either past/future assignments
- Ze Chen
  - Ze will work with Haodong on the assignment creations as well as helping out with any of the other user stories
- Yu Heng Su
  - Yu Heng will be working on the base template for the web pages, as well as the course creation and helping with any of the other user stories
- Tya Jubandhu
  - Tya will be working on the backend of the Login/Logout/Register. He will mostly be handling the database tasks
- Evan Gilchrist
  - Evan will be working on creating the home page UI
- Brendan Maclean
  - Brendan will be working on creating the course pages UI
