# AppBuilders - GradeCalc Tool Competitions

## Competitors
Since this tool is used for academic purposes, there are also some other great tools deployed and evolve for a long time. For example,
* [Google classroom](https://edu.google.com/products/classroom/?modal_active=none)
* [Blackboard](https://www.blackboard.com/teaching-learning/learning-management/mobile-learning-solutions)
* [Canvas student (Quercus)](https://toolboxrenewal.utoronto.ca/)

The Gradecalc Tool we building is a website-base application. All competitors above implement website-base client. And we focus on competing with Quercus here since it is currently used as a course task management tool in University of Toronto.

## Beneficial scenarios 
* As a university student, he\she would like to be able to know his\her GPA/CGPA from all the course grade he\she have inputted so that he\she can always reference his\her GPA when needed. 

Quercus does not ship with this functionality. In Gradecalc Tool the users are able to know\predict their GPA\CGPA by inputting course grades. Then they will have an idea about what goal to establish to maintain their GPA, which is another feature of our application. Of course there are alternative websites that can perform this task so Quercus does not include this feature. We would like to integrate this into our application since it is closely related to course grade and most users do care about their GPA.

* As a student he\she wants to add the weight of each assignment and test so he\she can keep track of how much each assignment/test are worth towards he\her final grade.

Quercus ships with a grade module which presents assignment, homework marks to students in a spreadsheet. Users control on this module is very limited to just know what mark they get. They can change marks for certain task but no more helpful information provided. In the Gradecalc Tool, students can assignment weight for each task for calculation and remind themselves how much each assignment\test count toward their final grade. Users have more space to manipulate in the grade module so they will know how well they need to perform.

* As a high-achieving student, he\she would like to be able to set goals that he\she would like to achieve for future assignments and tests.

As mentioned in the last scenario, users are able to set their goals. Basically, the goal can be the grade they wish to achieve. They can set up goals freely for each assignment or test while Quercus does not have this feature. 

* As an organized student, he\she wants to see all his\her current courses and their corresponding overall grade in the homepage so he\she can easily see his\her current grades and easily navigate to each course.

Quercus’s homepage only consists of colourful courses tabs which user can navigate to a specific course. In the Gradecalc Tool’s homepage, each course tab have option to include the overall grade for those organized students who want to see their mark at a glance. Also, completed courses and new courses have separate sections for users to organize their courses accordingly. We believe Quercus just want the homepage to include some necessary information such as notification icon and course tabs but we are giving the user more ability to customize the homepage.

