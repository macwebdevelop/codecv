import React, { Component } from 'react';
import Calendar from 'react-calendar';
import CalenderController from '../componentControllers/CalendarController.js';
import { auth } from '../databaseController/firebase.js';
import '../css/calendar.css';
import 'react-calendar/dist/Calendar.css';

class Calender extends Component {
    constructor(props) {
		super(props);
		this.state = {
		  user: null
		}
		this.controller = new CalenderController(this.props);
    }
    componentDidMount(){
        auth.onAuthStateChanged((user) => {
          if (user) {
            this.controller.deadlineView(user.email);
            this.controller.currentDateView();
          } 
          else{
            this.controller.deadlineView(null);
          }
        });
    }
    render() {
        return (
            <div>
                <h1 id="currentDate"></h1>
                <div className="calenderDiv">
                    <Calendar locale="en"/>
                </div>
                <div className="calenderDeadlines">
                </div>
            </div>
        );
    }
}

export default Calender;