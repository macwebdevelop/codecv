# Our Definition of "Done"

Our definition of “done” will be split up into 2 cases. The main case will be about the user stories and the second will be about the whole application itself.

We define a user story as being done if the user story is properly implemented and fully functional, meaning it meets all the acceptance criteria and the criteria of satisfaction. The user story should also not contain any bugs and should have a clear path to being added to the actual application as a whole. As the final step for all user stories, they must be reviewed and verified by other team members before designating them as completed

We define the whole application as done if and only if all the user stories and functions are properly and efficiently implemented without error. If we are somehow unable to complete all the user stories, then the user stories with higher priority should be completed. The whole application must also look clean in terms of the UI and the applications should have fluid transitions between the functions.
