# Team Name: AppBuilders

## Team Members (Name - UTORID):
- Yu Heng Su - suyuheng   
- Brendan MacLean - macle111  
- Tya Jubandhu - jubandhu
- Ze Chen - chenze4
- Evan Gilchrist - gilchr38
- Haodong Mai - maihaodo


## Guidelines
- Methods of communication (email, phone, messenger, text, .  .  .  )  
Our method of communcation will be through text and as well as Discord voice calls and messages

- Record your preferred phone number, email address etc.  with each other  
  - Yu Heng Su - 289 983 5712, yuheng.su@mail.utoronto
  - Brendan Maclean - 416 433 2560, brendan.maclean@mail.utoronto.ca
  - Ze Chen - 647 785 2721 timmy.chen@mail.utoronto.ca
  - Tya Jubandhu - 647 403 4267, tya.jubandhu@mail.utoronto.ca
  - Evan Gilchrist - 905 601 2400, evan.gilchrist@mail.utoronto.ca
  - Haodong Mai - don.mai@mail.utoronto.ca

- Communication response times (email, phone, messenger, text, .  .  .  )  
All group members should be able to reply to any texts and Discord messages within an hour. As for emails, it should take at most a few hours for response time

- Standup/other agile meetings (meet where, face-to-face vs.  online, who takes minutes, .  .  .  )  
We will be meeting every week during our tutorial time which is from 10-11am on Thursdays as well as out of class meetings, dates and time will be scheduled a week prior to the meeting to accomodate for everyone's class schedules. On days we are not able to meet in person, we will have online meetings through Discord

- Meeting preparation (whether preparation is needed, what to prepare, .  .  .  )  
For every meeting, each team member will need to prepare a quick summary of what they accomplished and what they will be working on next. 

- Version control (what to/not to commit, content of log messages, .  .  .  )  
Each group member will create separate branches from the master branch, and will commit as they work on their user stories. This is to prevent any merge conflicts and to minimize the loss of work incase any problem arises. Commit messages should be done in  one to two message summarizing what was completed, if the member needs to log a longer message, a textfile should be used along side the commit message

- Roles and division of work (how to divide work, who will decide who does what, .  .  .  )  
The work will be divided up equally, each members will work on both easy and difficult task. We will be deciding as a group which group member will do which task. We will give each group members tasks they are most comfortable with, as well as challenging tasks so they can improve their technical skills

- Submitting sprint deliverables and software (when to submit, who will submit, who will review the submission to make sure it is complete and correct, .  .  .  )  
We will be submitting our first sprint deliverable January 30th and we will be submitting it through github. Each member will merge their branch with the master branch, and a reviewer will be chosen every week to make sure all deliverables are submitted and are correct

- Contingency planning (what if a team member drops out, what if a team member misses meetingsor does not complete agreed upon tasks on time, what if a team member is academically dishonest,.  .  .  )  It is important not to let such situations continue.  Ignoring the problem never solves it  
If a team member drops out, that specific team member's work will be equally distributed among the rest of the group members. If a team member misses meeting, they are required to ask other team members who participated in the meeting for information about the meeting. If a team member does not complete agreed upon tasks on time, they will need to let other team members and look to finish that task and start the next task as soon as possible.
