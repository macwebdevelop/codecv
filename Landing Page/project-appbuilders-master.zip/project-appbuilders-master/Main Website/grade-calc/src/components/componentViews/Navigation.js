import React, { Component } from 'react';

import { NavLink } from "react-router-dom";
import { auth } from '../databaseController/firebase.js';
import {logout} from '../componentControllers/LoginController.js';
import "../css/nav.css";

class Navigation extends Component {
   constructor() {
      super();
      this.state = {
        user: null
      }
    }
    
    componentDidMount() {
      auth.onAuthStateChanged((user)=>{
        if(user){
            console.log("sign in as", user.uid);
            this.setState({ user: user.uid });
          }else{
            console.log("not signed in");
            this.setState({ user: null });
          }

    });

    }
  render() {
    //The navigation bar will be changed at the end
    return (
      <div className="navbar">
        <NavLink to="/home"className="title" >Up-Grade</NavLink>
        <ui className = "links">
          {/* <NavLink className="links" to="/" style={{paddingRight: "200px"}}> Login</NavLink> */}
          {/* <li><NavLink to="/register">Register</NavLink></li> */}
          {/* <li><NavLink to="/temporary">Temp</NavLink></li> */}
          <li><NavLink to="/tutorial">Help</NavLink></li>
          <li><NavLink to="/calculator">Calculator</NavLink></li>
          <li><NavLink to="/calendar">Calendar</NavLink></li>
          <li><a onClick={() => { logout(this)}} style={{cursor:"pointer"}}>Logout</a></li>
        </ui>
      </div>
    );
  }
}

export default Navigation;
