# Help

## First thing you should do when you first pull this branch is to download Node.js
- https://nodejs.org/en/
- This will allow you to run npm
- NOTE: All the npm commands should be ran in CMD

## How to test your code
- Run npm install first
- To test your code, all you need to do is run 'npm start', and this should start a local host for you. This should work with the database as well
- After running 'npm start', it should open a localhost site on your browser, if it didn't just go to 'http://localhost:3000/'

## How to deploy to the hosting site
- The updated website should only be deployed when it is in the master branch after all of its bug has been fixed. Please request another team member to review everything before deploying.
- In order to deploy, you need to first need to run 'npm install -g firebase-tools'
- Then 'npm login' which should then open your browser to firebase's website, which you should then login using our project gmail account. (Please see discord for login information)
- Then to deploy, all you need to do is run 'npm run build && npm run deploy'

## Side Note
- I have created a Javascript for home page, course page and the login page, this is where you should be working on both the front-end and the backend. You may add additional Javascript and CSS file if you want and just import them as needed. 
- I have also added some comments in each of the Javascript files to indicate where the codes should go
- Please do not touch any of there other Javascript or JSON files before asking Benson
- I have attached an example code for everyone to take a look at. This code will not compile so please don't try to run it, it is mainly to visualize where codes go in the file.
- If you would to see a running website that I have created with React and Firebase, visit https://testing-c47c3.web.app/
- For this example, I just followed the tutorials that I linked in the referenced text file. This example uses the firebase database and react
- NOTE THE TESTING SITE WAS JUST A TEST SITE, THERE IS PROBABLY BUGS SOMEWHERE

## Any further questions, please message Benson

