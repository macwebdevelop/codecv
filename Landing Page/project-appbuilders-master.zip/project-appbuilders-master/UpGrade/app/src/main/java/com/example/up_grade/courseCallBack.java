package com.example.up_grade;

import java.util.Map;

public interface courseCallBack {
    void oncourseCallBack(Map data);
}
