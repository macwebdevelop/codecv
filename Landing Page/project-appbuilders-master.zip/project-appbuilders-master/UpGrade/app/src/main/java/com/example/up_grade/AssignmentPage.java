package com.example.up_grade;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Map;

public class AssignmentPage extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private Button signOutButton, assignmentButton, courseButton;
    private TextView assignmentName, goal, grade, weight;//**, calculatedGoal, dueDate**//
    private Switch completedSwitch;
    private firebaseController controller = new firebaseController();
    private String TAG = "AssignmentPageActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment_page);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        mAuth = FirebaseAuth.getInstance();

        assignmentName = findViewById(R.id.assignment_name);
        goal = findViewById(R.id.goal);
        grade = findViewById(R.id.grade);
        weight = findViewById(R.id.weight);
        //calculatedGoal = findViewById(R.id.calculated_goal);
        //dueDate = findViewById(R.id.due_date);
        completedSwitch = findViewById(R.id.assignment_completed);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        String personEmail = account.getEmail();

        Intent intent = getIntent();
        final String course_code = intent.getStringExtra("Course Code");
        final String assignment_name = intent.getStringExtra("Name");
        Log.w(TAG, course_code + " and " + assignment_name);

        controller.getAssignmentInfo(personEmail, assignment_name, course_code, new courseCallBack() {
            @Override
            public void oncourseCallBack(Map data) {
                Log.w(TAG, data.get("Name").toString());
                assignmentName.setText(data.get("Name").toString());
                String goalText = "Goal: " + data.get("Goal").toString();
                goal.setText(goalText);
                String gradeText = "Grade: " + data.get("Grade").toString() + " out of " + data.get("Total Grade").toString();
                grade.setText(gradeText);
                String weightText = "Weight: " + data.get("Weighting").toString() + "%";
                weight.setText(weightText);
//                String calculatedGoalText = "Calculated Goal: " + data.get("Calculated Goal").toString();
//                calculatedGoal.setText(calculatedGoalText);
//                String dueText = "Due Date: " + data.get("Deadline").toString();
//                dueDate.setText(dueText);
                boolean status = (boolean) data.get("Completed");
                if(status){
                    completedSwitch.setChecked(true);
                }else{completedSwitch.setChecked(false);}
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_assignmentpage, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.sign_out_button:
                mAuth.signOut();
                updateUI();
                Toast.makeText(this,"You are Logged Out",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateUI(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

}
