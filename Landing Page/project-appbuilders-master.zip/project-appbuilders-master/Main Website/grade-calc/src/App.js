import React, { Component } from 'react';

import { BrowserRouter, Route, Switch } from 'react-router-dom';
 
import Login from './components/componentViews/Login';
import Register from './components/componentViews/Register';
import Home from './components/componentViews/Home';
import Course from './components/componentViews/Course';
import Error from './components/componentViews/Error';
import Navigation from './components/componentViews/Navigation';
import Temporary from './components/componentViews/Temporary';
import Tutorial from './components/componentViews/Tutorial';
import Calculator from './components/createItems/Calculator';
import Calendar from './components/componentViews/Calendar';
import Graph from './components/componentViews/Graph';
 
class App extends Component {
  render() {
    return (
      <BrowserRouter>
      <div>
        <Navigation />
          <Switch>
           <Route path="/" component={Login} exact/>
           <Route path="/register" component={Register}/>
           <Route path="/home" component={Home}/>
           <Route path="/course" component={Course}/>
           <Route path="/temporary" component={Temporary}/>
           <Route path="/calculator" component={Calculator}/>
           <Route path="/tutorial" component={Tutorial}/>
           <Route path="/calendar" component={Calendar}/>
           <Route path ="/graph" component={Graph}/>
          <Route component={Error}/>
         </Switch>
      </div> 
      </BrowserRouter>
    );
  }
}

export default App;