import React from "react";
import { addAssignment } from "../databaseController/firebase.js";
import { updateCourse } from '../componentControllers/GradeCalculations';

export default class CompletedAssignment extends React.Component {
  constructor() {
    super();
    this.state = {
      name: "",
      type: "Assignment",
      gradeRecieved: "",
      gradeGoal: "",
      gradeTotal: "",
      weight: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  handleSubmit(e) {
    e.preventDefault();
    const code = this.props.code;
    addAssignment(
      code,
      this.state.type,
      this.state.name,
      parseInt(this.state.gradeRecieved),
      parseInt(this.state.gradeGoal),
      parseInt(this.state.gradeTotal),
      parseInt(this.state.weight),
      true,
      -1,
      new Date()
    );
    updateCourse(code);

    this.setState({
      name: "",
      Type: "Assignment",
      gradeRecieved: "",
      gradeGoal: "",
      gradeTotal: "",
      weight: ""
    });
  }
  render() {
    return (
      <div className="modalInfo">
      <h1 id="pastAssignments">Adding Completed Assignment</h1>
      <form onSubmit = {this.handleSubmit.bind(this)}>
      <label>Type: </label><select className="documentType" name ="type" onChange={this.handleChange} value={this.state.type}>
          <option value="Assignment">Assignment</option>
          <option value="Test">Test</option>
          <option value="Other">Other</option>
      </select>
      <br></br>
      
          <div className="documentInfo">
          <label>Assignment name: </label>
          <input type="text" className="inputForm" name="name" onChange={this.handleChange} value={this.state.name}/>
          <br></br>
          <label>Assignment weight: </label>
          <input type="text" className="inputForm" name ="weight" onChange={this.handleChange} value={this.state.weight}/>
          <br></br>
          <label>Grade Recieved: </label>
          <input type="text" className="inputForm" name ="gradeRecieved" onChange={this.handleChange} value={this.state.gradeRecieved}/>
          <br></br>
          <label>Goal for the grade: </label>
          <input type="text" className="inputForm" name ="gradeGoal" onChange={this.handleChange} value={this.state.gradeGoal}/>
          <br></br>
          <label>Grade total: </label>
          <input type="text" className="inputForm" name ="gradeTotal" onChange={this.handleChange} value={this.state.gradeTotal}/>
          </div>
          <button className="saveButton">Save</button>
      </form>
  </div>
  
    );
  }
}
