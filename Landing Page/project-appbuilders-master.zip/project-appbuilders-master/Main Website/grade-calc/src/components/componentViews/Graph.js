import React, { Component } from 'react';
//Any imports would go here
import {Line} from 'react-chartjs-2';
import '../css/graph.css';
  
class Graph extends Component{
    constructor(props) {
        super(props);
        const { name } = this.props.location.state;
        const { grade } = this.props.location.state;
        const { code } = this.props.location.state;
        this.courseCode = code;
        this.data = {
            labels: name,
            datasets: [
              {
                label: 'Assignment Grade Distribution',
                fill: false,
                lineTension: 0.1,
                backgroundColor: 'rgba(255,255,255,255)',
                borderColor: 'rgba(255,255,255,255)',
                borderJoinStyle: 'miter',
                pointBorderColor: 'rgba(255,255,255,255)',
                pointBackgroundColor: '#fff',
                pointBorderWidth: 1,
                pointHoverRadius: 5,
                pointHoverBackgroundColor: 'rgba(255,255,255,255)',
                pointHoverBorderColor: 'rgba(255,255,255,255)',
                pointHoverBorderWidth: 2,
                pointRadius: 1,
                pointHitRadius: 10,
                data: grade
              }
            ]
          };
          this.goBack = this.goBack.bind(this);
    }
    goBack(){
        console.log("Directing to graph");
        this.props.history.push({pathname: '/course',state: {code: this.courseCode}})
        return true;
    }
    render() {
        return (
          <div>
            <h2 className ="graphTitle">Graph of assignment grade</h2>
            <Line data={this.data} width={400} height={150} />
            <p className="goBack" 
            onClick= {() => {this.goBack()}}
            >Go Back
            </p>
          </div>
        );
  }
}

export default Graph;
