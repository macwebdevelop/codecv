//Do not remove this import
import React, { Component } from 'react';
//Any imports would go here
import '../css/home.css';
import HomeController from '../componentControllers/HomeController.js';
import { auth, getUserCourses } from '../databaseController/firebase.js';
import NewCourse from '../createItems/NewCourse.js'
import CompletedCourse from '../createItems/CompletedCourse.js'

class Home extends Component {
    //ANY BACK END CODE/FUNCTIONS WOULD GO HERE
	constructor(props) {
		super(props);
		this.state = {
		  user: null
		}
		this.controller = new HomeController(this.props);
	}

  componentDidMount(){
	  document.body.style = "overflow: auto"
	  auth.onAuthStateChanged((user) => {
		if (user) {
		  this.setState({ user });
		  getUserCourses(user.email)
		  .then(result => {
				this.controller.homeView(result);
				this.controller.gpaView(result);
				this.controller.deadlineView(user.email);
			})
		} 
		else{
			this.props.history.push({pathname: '/'});
		}
	  });
  }

  render() {
    return (
		// FRONT END CODE GOES HERE
		<article id="courses">
			<h1 id="gpaInfo"></h1>
			<h1 className="deadlineTitle">Upcoming Deadlines</h1>
			<div className="deadlinesContainer">
			</div>
			<div class="grid-container" id="content">
				<div class="proj-span2-title">
				</div>
            </div>
			<div className="corner" style={{position: "fixed", bottom: "50px", right:"50px" , z: "999"}} >
					<div className="dropdownContent">
						<ui className="dropdownList">
						<li><NewCourse /></li>
						<li><CompletedCourse /></li>
						</ui>
					</div>
				<button className="courseButton">New Courses +</button>
			</div>
        </article>
    );
  }
}
export default Home;