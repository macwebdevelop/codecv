import React from 'react';
import Popup from "reactjs-popup";
import { examGrade } from '../componentControllers/GradeCalculations';

const assignments = [
  {"Completed": true,
  "Goal": 90,
  "Grade": 50,
  "Name": "A3",
  "Total Grade": 100,
  "Type": "Assginment",
  "Weighting": 20},
  {"Completed": true,
  "Goal": 90,
  "Grade": 70,
  "Name": "A3",
  "Total Grade": 100,
  "Type": "Assginment",
  "Weighting": 20},
  {"Completed": true,
  "Goal": 90,
  "Grade": 90,
  "Name": "A3",
  "Total Grade": 100,
  "Type": "Assginment",
  "Weighting": 20},
  
]

export default class TempExamGrade extends React.Component {
  //courseGradeGoal is the grade they want to achieve in the course
  //gradeGoal is their goal for this sepcific assignment/test
  //type is the type of the assignment/test, for temporary, I just set it to be Exam by default
  
    constructor() {
        super();
        this.state = {
          weighting:'',
          courseGradeGoal:'',
          gradeGoal: '',
          type: 'Exam'
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this); 
      }

        handleChange(e) {
          this.setState({
            [e.target.name]: e.target.value
          });
        }

        handleSubmit(e) {
            e.preventDefault();
            console.log(this.state.type, ":");
            console.log("Grade you will need on the", this.state.type, "to achieve the overall course grade goal",this.state.courseGradeGoal, "is: ");
            console.log(examGrade(parseInt(this.state.courseGradeGoal), parseInt(this.state.weighting), assignments));
            this.setState({
              weighting:'',
              courseGradeGoal:'',
              gradeGoal: ''
            });
          }
  render() {
    return (
        //This creates the popup form, once you submit the form, it will run handleSubmit
        <Popup trigger = {<button className='dropbutton'> Exam</button>} modaltrigger position = "bottom center">

            <div className="modal">
                <div className="modalContent">
                <div className="modalHeader"> Exam </div>
                <form className = "input" onSubmit = {this.handleSubmit.bind(this)}> 
                    <input className = "inputForm" type="text" name="courseGradeGoal" placeholder="Course Grade Goal" onChange={this.handleChange} value={this.state.courseGradeGoal} />
                    <input className = "inputForm" type="text" name="gradeGoal" placeholder="Grade Goal" onChange={this.handleChange} value={this.state.gradeGoal} />  
                    <input className = "inputForm" type="text" name="weighting" placeholder="Weighting" onChange={this.handleChange} value={this.state.weighting} />
                    <button className = "submitButton">Submit</button>
                </form>
                </div>
            </div>

      </Popup>
    );
  }
}
