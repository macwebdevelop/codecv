package com.example.up_grade;

import java.util.List;
import java.util.Map;

public interface callBack {
    void onCallBack(List<Map> data);
}
