# Sprint 2 Planning
## Goal:
- Our goal for this sprint to implement our writing and reading from the database and finish setting up all the basic functions of our application. We are also going to start learning android development and start integrating the functions into the android application.

## User stories for this sprint will be (Along with subtasks):
- Learning Mobile
- UI
- Splitting front end code and back end code
  - Split up the codes
  - Organize the scripts
- User Data
  - Backend Get Courses
  - Backend Get Assignments
  - Backend Get User Specific Data
  - Backend Get User Info
  - Backend Unique Logins
  - Backend Valid Passwords
  - Persisting login
  - Backend Fix Writing Informations
  - Backend register/login
- The ability to add the weights of assignments/tests
- Ability to add marks to the assignments/tests
- Setting goals for assignments and tests
- Current grade
  - Calculate the grade
  - Update grade in database
- Exam grade calculator
  - Compute the calculation
- Switching from future assignments/tests to finished assignments/tests
  - Temporary assignment status dropdown
  - Change assignment status in the database
- Switching from future assignments/tests to finished assignments/tests
- We chose these user stories for our sprint 2 because these user stories are all of our basic functions that we want in our applications. As soon as we finish these, we can start polishing the application and start adding in more advance features. We also want to start learning mobile development now while it is still early in the development stages. This way, as we move on in our sprints, we can start implementing the mobile application

## Participants:
- Haodong Mai
  - Haodong will work on switching the statuses on assignments/tests and helping out with the user data
- Ze Chen
  - Ze will work on polising up the UI for all the web pages
- Yu Heng Su
  - Yu Heng will be working on the exam grade calculator, current grade, splitting up the codes, learning android development and helping out with the user data
- Tya Jubandhu
  - Tya will mainly focus working on the user data
- Evan Gilchrist
  - Evan will be responsible for switching the statuses on the courses and helping out with the UI 
- Brendan Maclean
  - Brendan will be focus on learning android development and start to implement some base foundations for the application

## Team Capacity
- Number of ideal days we should spend working on the application is roughly 8-9 days per team member, this leaves 4-5 days for everyone to complete assignments for other courses. Since it is midterm season this sprint, we are reducing the ideal days for each team member so they can focus on their midterms.
- So our overall team capacity would be:
  - 9 * 6 = 54
  - So our team capacity is roughly 54
