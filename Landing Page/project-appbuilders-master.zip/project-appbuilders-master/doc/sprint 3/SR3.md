#  Sprint 3 Retrospective Meeting

## Participants
- Haodong Mai
- Tya Jubandhu
- Ze Chen
- Brendan Maclean
- Yu Heng Su
- Evan Gilchrist

## Some Practices to Continue
- Regular Meetings:
  - Bring up any problems or suggestions during standup to increase the quality of the application
- Asking questions:
  - It is always okay to seek clarity about the user stories
  - Always ask for help with problems and bug if needed
- Starting the work earlier
  - Focus on finishing the user stories before the deadline to allow room for bug fixing
- Constantly testing the corner cases for the code
  - To ensure no bug breaking codes

## New Practices
- Code organization
  - Clean up code that is not needed
  - Delete any unnecessary comments/codes

## Unfinied User Stories
- Calender
- Graphing the data

## New User Stories for Sprint 4
- Tutorial page for teachers and anyone trying to demonstrate the application
  
## New Potential Features for Sprint 4
- Degree planner
  
## Best Experience
- Creating the dynamic page
- Designing the mobile user interface
- Adding the existing features onto our final application pages

## Worst Experience
- Figuring out synchronous and asynchronous functions
- Trying to fix bugs for the mobile application
