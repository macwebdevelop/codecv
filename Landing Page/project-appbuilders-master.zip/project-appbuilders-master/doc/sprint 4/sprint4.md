# Sprint 4 Planning
## Goal:
- Our goal for this sprint is to finish off the website, this mean connecting all the features that were implemented in the previous sprints to the website, as well as adding in some final features to the website. During this sprint, we will also be finishing up the basics of the mobile application, this inclues some of the basic functions.

## User stories for this sprint will be (Along with subtasks if any):
- Graphing the data
- Calender
- Notification
  - Backend get upcoming deadline
  - Frontend displaying upcoming deadlines
- Connecting features
  - Connect progress
  - Update login UI
  - Delete Function
  - Exam Grade
  - Deadline
  - Connect notes
  - Notification
  - Calender
  - Graph
- Connect the backend with the front end on mobile
  - Assignmnet creation
- Journal/Log
  - Write to database
  - Retrieve data from the database
  - Display the data
- Finalize the mobile UI and function
- GPA Calculator
  - Calculate the GPA
- Teacher Tutorial
  - Create help images
  - Create new web page
  - Combine the subtasks together
- We chose these user stories for our sprint 4 because these are the user stories that will finish off both our website and mobile application. As well as adding in the final features that we want to have in both of the applications.

## Participants:
- Haodong Mai
  - Haodong will work connecting the back end with the front end on the mobile, and also helping Brendan with the mobile development.
- Ze Chen
  - Ze will work on finishing graphing the data.
- Yu Heng Su
  - Yu Heng will be working on connecting all the features, the gpa calculator, and the tutorial page. Also he will be helping  anyone that needs help finishing their user story.
- Tya Jubandhu
  - Tya will be working on figuring out a notification system
- Evan Gilchrist
  - Evan will be responsible for finishing up the calender.
- Brendan Maclean
  - Brendan will be focus finishing up the mobile user interface as well as implementing the main functions of the application.

## Team Capacity
- Number of ideal days we should spend working on the application for this sprint is roughly 7-8 days per team member, since we are near the end of the semester, a lot of classes will have upcoming deadlines. Therefore by only having 7-8 days per team member, this will allow all the members time to work on assignments from other classes.
- So our overall team capacity would be:
  - 9 * 6 = 48
  - So our team capacity is roughly 48
