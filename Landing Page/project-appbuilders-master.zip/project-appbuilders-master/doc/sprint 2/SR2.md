#  Sprint 2 Retrospective Meeting

## Participants
- Haodong Mai
- Tya Jubandhu
- Ze Chen
- Brendan Maclean
- Yu Heng Su
- Evan Gilchrist

## Some Practices to Continue
- Regular Meetings:
  - This helped us a lot during this sprint since we are constantly updating each other what is being worked on
- Asking questions:
  - It is always okay to seek clarity about the user stories
  - Always ask for help with problems and bug if needed
- Starting the work earlier
  - Focus on finishing the user stories before the deadline to allow room for bug fixing
- Staying Work-Focused
  - Be more focus when working on the user stories 
- Constantly testing the code
  - To ensure as little bugs as possible

## New Practices
- Writing unit tests
  - This will help test for any bugs
- Reduce repetition
  - Combine codes that repeat or has similar uses
- Write more comments
  - This will allow other developers understand what the code does

## New User Stories for Sprint 3
- Mobile User Data
- Mobile UI
- Mobile Connection
- Mobile Basic Functions
  
## New Potential Features for Sprint 3
- Degree planner
- Features to include the teacher as the user
  - Allow teachers to leave feedback for the students
  
## Best Experience
- Learning how to work with firebase
- Learning android development

## Worst Experience
- Figuring out synchronous and asynchronous functions
