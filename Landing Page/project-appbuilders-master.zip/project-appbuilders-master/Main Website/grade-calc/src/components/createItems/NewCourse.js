import React from 'react';
import Popup from "reactjs-popup";
import {addCourse} from '../databaseController/firebase.js'


export default class NewCourse extends React.Component {
    constructor() {
        super();
        this.state = {
          coursecode:'',
          coursename: '',
          coursegoal:'',
          prof: '',
          ta: ''
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this); 
      }

        handleChange(e) {
          this.setState({
            [e.target.name]: e.target.value
          });
        }

        handleSubmit(e) {
            e.preventDefault();
            addCourse(this.state.coursecode, this.state.coursename, 100, 0, false, 0, this.state.prof, this.state.ta);

            this.setState({
              coursecode:'',
              coursename: '',
              coursegoal:'',
              prof: '',
              ta: ''
            });
          }
    print(text){
        console.log(text);
    }
  render() {
    return (
        //This creates the popup form
        <Popup trigger = {<button className='contentButton'> New Course</button>} modaltrigger position = "left center">

            <div className="modal">
                <div className="modalContent">
                <div className="header"> New Course </div>
                <form className = "input" onSubmit = {this.handleSubmit.bind(this)}>
                    <input className = "inputForm" type="text" name="coursecode" placeholder="Course Code" onChange={this.handleChange} value={this.state.coursecode} />
                    <input className = "inputForm" type="text" name="coursename" placeholder="Course Name" onChange={this.handleChange} value={this.state.coursename} />
                    <input className = "inputForm" type="text" name="coursegoal" placeholder="Course Goal" onChange={this.handleChange} value={this.state.coursegoal} />
                    <input className = "inputForm" type="text" name="prof" placeholder="Professor" onChange={this.handleChange} value={this.state.prof} />
                    <input className = "inputForm" type="text" name="ta" placeholder="Teacher Assistant" onChange={this.handleChange} value={this.state.ta} />
                    <button className = "submitButton">Submit</button>
                </form>
                </div>
            </div>

      </Popup>
    );
  }
}