// //Do not remove this import
// import React, { Component } from 'react';
// //Any imports would go here
// import {changeAssignmentStatus} from "../databaseController/firebase.js";

// export default class SwitchAssignmentStatus extends Component {
//   //ANY BACK END CODE/FUNCTIONS WOULD GO HERE
//   constructor(){
//     super();
//     this.state = {
//       complete: false
//     };
//     this.handleChange = this.handleChange.bind(this);
//     this.handleSubmit = this.handleSubmit.bind(this);
//   }

//   handleChange(e) {
//     this.setState({
//       [e.target.name]: Boolean(e.target.value)
//     });
//   }

//   handleSubmit(e){
//     changeAssignmentStatus(this.state.complete);
//   }
  
//   render() {
//     return (
//         // FRONT END CODE GOES HERE
//         <div>
//         <h1>Change assignment status</h1>
//         <form onSubmit={this.handleSubmit.bind(this)}>
//         <select
//             id="completeDropdown"
//             name="complete"
//             onChange={this.handleChange}
//             value={this.state.complete}
//           >
//             <option value="true">Completed</option>
//             <option value="false">Pending</option>
//           </select>
//           <br></br>
//         <input type="submit" value="save"></input>
//         </form>
//         </div>
//     );
//   }
// }