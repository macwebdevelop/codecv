import { Component } from 'react';
import {getAllDeadlines} from '../databaseController/firebase.js';
export default class CalendarController extends Component{
	constructor(props)
	{
		super(props);
    }
    
    currentDateView(){
        let h1 = document.getElementById('currentDate');
        let start = new Date();
        start.setDate(start.getDate());
        h1.innerHTML = "Current Date: " + start.toLocaleDateString();
    }
    async deadlineView(userEmail){
        if (userEmail == null){
            let container = document.querySelector('.calenderDeadlines');
            var deadline = document.createElement("li");
            deadline.innerHTML = "Not Logged In";
            deadline.className = "noInfo";
            container.appendChild(deadline);
        }
        else
        {
            await getAllDeadlines(userEmail)
            .then (result => {
                console.log(result);
                let container = document.querySelector('.calenderDeadlines');
                for (var i = 0; i < result.length; i ++){
                    var deadline = document.createElement("li");
                    var courseCode = document.createElement("a");
                    courseCode.innerHTML = result[i][0] + ": ";
                    courseCode.className = "deadlineCode";
    
                    deadline.innerHTML = result[i][1]["Name"] + ": " + result[i][1]["Deadline"].toDate().toLocaleDateString();
                    deadline.className = "calenderInfo";
    
                    deadline.prepend(courseCode);
                    container.appendChild(deadline);
                }
            })
        }

    }
}