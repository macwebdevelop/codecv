import { auth, provider, firebase} from '../databaseController/firebase.js';
import {verifyUserDataWithGoogle} from '../databaseController/firebase.js'

export async function login(currentState) {
  ////////////////////////////Google signin//////////////////////////////
  await firebase.auth().setPersistence(firebase.auth.Auth.Persistence.SESSION)
  .then(async function() {
    const result = await auth.signInWithPopup(provider);
    const user = result.user.uid;
    currentState.setState({ user });
    console.log("now sign in as", user);

    auth.onAuthStateChanged((currentuser)=>{
      if(currentuser){
        verifyUserDataWithGoogle(currentuser);
      }
    });

  })
}

export function logout(currentState) {
  auth.signOut().then(() => {
    currentState.setState({ user: null });
  }).catch(function(error) {
    console.log("unsuccessful signout");
  });
  window.location.href='/';
}
