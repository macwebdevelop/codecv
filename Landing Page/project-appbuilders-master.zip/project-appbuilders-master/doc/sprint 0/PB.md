# Product Backlog

## Estimation
We will be using the Fibonacci sequence as our numerical series to estimate our user story complexity since this sequence provides us with gives us a good range of numbers to use as complexity. The numbers from the Fibonacci sequence can also be used to show the difference in complexity between tasks and how close each tasks are to one another. With the estimation alongside with the priority,we can further improve our sprint planning by planning the number of tasks accordingly to their complexity,
either having less tasks with higher complexity or more tasks with less complexity. 

## The Important user stories include:
- The ability to log in as the user and save the current data
- The ability to log out
- The ability to add tests/assignments and their corresponding mark
- To be able to create new courses from the homepage
- To be able to see all the classes and their course marks in the home page

## User Stories:

Priority: Higher the number means higher the priority(5 is the highest, 1 is the lowest) <br/>
Estimation: Will be using the Fibonacci series

- As a student, I would like to be able to login to my account so I can look at my saved data
  - Priority : 5
  - Estimate: 21
  - CoS:
    - Make sure data isn’t lost and users can’t access other user’s information
    - Make sure the user can login using their email and password
    - Make sure the user can not login unless it is the correct email and password
    - All the data from only their account is loaded when a user logs in
- As a user, I would like to register an account using an email and password so that my data can be saved and loaded on any devices
  - Priority: 5
  - Estimate: 21
  - CoS:
    - Make sure the emails and passwords are safely stored and somewhat encrypted
    - Make sure logins have proper access the emails and passwords
    - Make sure each account is private and no accounts can access other account's information
- As a user, I would like to be able to log out of my account save all my data so I can revisit them and update as the semester goes
  - Priority : 5
  - Estimate: 21
  - CoS:
    - Make sure the data is safely stored onto their account
    - Make sure the password and username isn’t saved in the login inputs
- As a student, I want each individual course to have its own page so that all the information is organized into its respective course
  - Priority : 5
  - Estimate: 13
  - CoS:
    - Make sure each page is formatted the same
    - Contains all the relevant information about the course
    - This should be the base template for the individual classes so when a new class is created, it just has to copy the template over
- As a student, I want to be able to add either past tests or past assignments so that I can keep track of what work has been done throughout the semester
  - Priority : 5
  - Estimate: 3
  - CoS:
    - Make sure there is a distinct difference between assignments and test
    - Support the ability to create sub assignments
    - Make sure the tests and assignment only shows up for their corresponding class
    - Properly displays all information
- As a planner, I want to be able to add future assignments and tests along with due dates so I can keep track of what I need to be working on at certain times
  - Priority : 4
  - Estimate: 5
  - CoS:
    - Make sure the past assignments and future assignments are properly separated
    - Make sure only valid dates can be inputted
    - Properly displays all information
- As a student I want to switch 'future assignments' to 'past assignments' when I am done the assignments, so I can keep track of what tasks has been done
  - Priority : 3
  - Estimate: 8
  - CoS:
    - Properly moves a future assignment to past assignment
    - Make sure the due date gets removed
    - Prompts the user to input the grade they received or the user can postpone the grade input if they have not received their marks yet 
- As a student I want to add the weight of each assignment and test so I can keep track of how much each assignment/test are worth towards my final grade
  - Priority : 3
  - Estimate: 2
  - CoS:
    - If an assignment is composed of smaller assignments, it should be able to calculate how much each sub assignment is worth by composing the average. (Example: Assignment is worth 15%, but there are 3 assignments in total ⇒ each assignment is worth 5%
    - Should display the weight near the grade
- As a student, I want to be able to add my marks to the individual tests and assignments so that I can keep track of what my marks are throughout the course
  - Priority : 4
  - Estimate:  2
  - CoS:
    - If there are sub assignments, input the grades in the sub assignments and display the current overall assignment grade
    - User can input their mark or postpone it if necessary
    - Marks should be in percentages
    - Should be one of the main displays in each assignment 
- As a student I want to see my current grade in  a course so I can know how well I am doing in the class
  - Priority : 3
  - Estimate: 8
  - CoS:
    - Displays the overall current grade near the top of the page
    - Calculates the current grade using the weights and marks of each assignment and tests
    - Should still works if not all the assignments and tests has a grade
    - Can calculate current grade by subtracting from 100%
- As a student who likes to see overviews of upcoming weeks, I want to be able to have a calendar with the due dates on them so I can keep track of upcoming assignments and other relevant information
  - Priority : 3
  - Estimate: 34
  - CoS:
    - Calendar should display all the due dates and events
    - Support the ability to look ahead in the calendar as well as the past
- As a high-achieving student, I would like to be able to set goals that I would like to achieve for future assignments and tests
  - Priority : 4
  - Estimate: 3
  - CoS:
    - Goals should be set to the grade they wish to receive
    - Should only allow 1 goal per assignment/test
- As an organized student, I want to see all my current courses and their corresponding overall grade in the homepage so I can easily see my current grades and easily navigate to each course
  - Priority : 5
  - Estimate: 13
  - CoS:
    - Make sure each course is distinctly different (Different colours)
    - The courses are organized in some sort of manner
    - When clicking on each course, it should take you to the correct course page
    - Should have a section for old courses and new courses
- As a student, I want to be able to change a 'current course' into a 'completed course' so the courses are properly organized
  - Priority: 3
  - Estimate 5
  - CoS:
    - The user should still have the ability to change the grades in the course after changing it to a completed course
    - Should display the overall grade received
- As a student, I want to be able to create new courses as I study different courses so I can keep track of them all
  - Priority: 5
  - Estimate 21
  - CoS:
    - When a new course is created, it should display on the homepage
    - Make sure the new course pages are created from the template
    - Current grade should be set to N/A or 100% if no marks have been inputted
    - Support the ability to create new or completed courses
    - Completed course should not create a new page, it should just display the grade 
    - When creating a completed course, it should ask for the grade
- As a university student, I would like to be able to know my GPA/CGPA from all the course grade I have inputted so that I can always reference my GPA when needed
  - Priority : 3
  - Estimate: 1
  - CoS:
    - Should only calculate the GPA with the completed course
    - Displays in the home page
- As a university student, I would like to be able to know what grade I need on the exam in order to achieve a certain grade in the course
  - Priority : 4
  - Estimate: 8
  - CoS:
    - Should ask the user what grade they would like to end with in the course and calculates the mark they need on the exam
    - If the mark they need is above 100, then displays N/A
    - User should also have an option to put their own goal for the exam alongside the calculated goal
- As a student who isn’t strong in mathematics, I would like to have a calculator to do any of my calculations that I might need as I use this application
  - Priority : 2
  - Estimate: 21
  - CoS:
    - Should function like a normal basic calculator
    - Should be accessible at all times.
- As a visual learner, I want to be able to see my marks in a classes displayed in a graph, so I can see if I am making any noticeable improvements.
  - Priority : 1
  - Estimate: 13
  - CoS:
Marks should be points in the graph
Should be a line graph
The graph should have labelled axis
